/*----------------------------------------------------------------------
  File    : fpgrowth.h
  Contents: fpgrowth algorithm for finding frequent sets
  Author  : Bart Goethals
  Update  : 4/4/2003
  ----------------------------------------------------------------------*/
#ifndef TRIXINDEXINFO_H
#define TRIXINDEXINFO_H
//#include "query.h"
#include "util.h"
#include <map>
#include <vector>
using namespace std;
class TrieIndexInfo
{
 public:

  TrieIndexInfo();
  ~TrieIndexInfo();

  void setData(Data *d){data = d;}
  //void setMinsup(unsigned ms){minsup = ms;}
  //void setOutput(char *of);
  //void setElementOrder(ElementOrder order) {elemorder =order; }
  //void setQuery(Query *qry) {query = qry;}
 /* int mine();*/
  //void createIndex();

  void onescan(Partition *p);
  //void process(Transaction *pre);

  //vector<int> search();

  //vector<int> subSetSearch();

  //map<int,vector<int>> join(vector<Query *> querys);

  //map<int,vector<int>> joinWithLengthPrune(vector<Query *> querys);
  void  writeOutput();


  void destory();

 private:

  //unsigned minsup;
  Data *data;
  //Query *query;
  Trie *trie;
  FILE *out;
  //ElementOrder elemorder;
public:
    int simType;
    float threshold;
    int triePreOrder;
};
#endif TRIXINDEXINFO_H
