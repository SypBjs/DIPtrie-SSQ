///*----------------------------------------------------------------------
//File    : trie.cpp
//Contents: trie index algorithm
//Author  : lianyin jia
//Update  : 04/10/2011
//----------------------------------------------------------------------*/
//
//#include <iostream>
//#include <stdio.h>
//#include <vector>
//#include <algorithm>
//
//#include <time.h>
//#include "data.h"
//#include "item.h"
//#include "trie.h"
//#include "trieindexinfo.h"
////#include "heap.h"
//#include "util.h"
//
//using namespace std;
//TrieIndexInfo::TrieIndexInfo() : data(0)
//{
//    trie = new Trie();
//}
//
//TrieIndexInfo::~TrieIndexInfo()
//{
//    if(data) delete data;
//    if(trie) delete trie;
//}
//
////void TrieIndexInfo::setOutput(char *of)
////{
////	out = fopen(of, "wt");
////}
//
//void TrieIndexInfo::onescan(Partition *p,int simType, float threshold,int triePreOrder)
//{
//    //data->opendata();
//    //int fid =0;
//
//    int lastlen =0;
//
//    out = fopen("stagetime.txt", "wt+");
//    clock_t start = clock();
//    //TrieNode *queryNode = new TrieNode();
//    double timelen;
//
//    for(int i =data->lenIdx[p->probeStartLen]->start;
//            i < data->lenIdx[p->accessStartLen]->start; i++)
//            {
//                trie->indexRecord
//
//            }
//
//    for(int i =data->lenIdx[p->probeStartLen]->start;
//            i < data->lenIdx[p->endLen]->start + data->lenIdx[p->endLen]->size; i++)
//    {
//
//        //trie->processItems(pre);
//        trie->partTrieJoin(data->vec_trans[i],simType,threshold,triePreOrder);
//        trie->indexRecord(data->vec_trans[i]);
//        trie->processedtrans++;
//    }
//    timelen= (clock()-start)/double(CLOCKS_PER_SEC);
//    fprintf(out,"total trans %d, Total time used %f s\n",trie->transcount,timelen);
//    fprintf(out," total trans %d\n,processed trans %d\n found pair %d\n total distinct words %d\n total nodes add %d\n total invert list number %d\n",
//            trie->transcount,trie->processedtrans,trie->foundpair,trie->words,trie->nodes,trie->totallistnumber);
//
//    fprintf(out,"nodes accessed %d, nodes got %d \n",trie->nodesaccessed,trie->nodesgot);
//
//    fclose(out );
//    //data->close();
//}
//
//void TrieIndexInfo::writeOutput()
//{
//    char *name="d:\\outputinfo.txt";
//    FILE *file = fopen(name,"w+");
//    fprintf(file," total trans %d\n,processed trans %d\n found pair %d\n total distinct words %d\n total nodes add %d\n total invert list number %d",
//            trie->transcount,trie->processedtrans,trie->foundpair,trie->words,trie->nodes,trie->totallistnumber);
//    fclose(file);
//}
////void TrieIndexInfo::createIndex()
////{
////	clock_t start;
////
////	//trie->setOutput(out);
////
////	//start = clock();
////
////	//data->readData();
////
////	//cout << "items read [" << (clock()-start)/double(CLOCKS_PER_SEC) << "s]" << endl;
////
////	Transaction *pre = data->trans;
////	while(pre)
////	{
////		trie->processItems(pre);
////		pre=pre->next;
////	}
////
////
////	pre = data->trans;
////	while(pre) {
////		 trie->processTransaction(pre);
////		 pre=pre->next;
////	}
////	//cout << "FPtree constructed [" << (clock()-start)/double(CLOCKS_PER_SEC) << "s]" << endl;
////}
//
//
//void TrieIndexInfo::destory()
//{
//    /*delete [] Trie::remap;
//    delete Trie::relist;*/
//}
//
