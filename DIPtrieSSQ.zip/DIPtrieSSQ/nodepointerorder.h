#ifndef NODEPOINTERORDER_H
#define NODEPOINTERORDER_H
#include "trienode.h"
class NodePointerOrder
{
public:
	bool operator()(TrieNode *tn1,TrieNode *tn2)
	{
		return tn1->getId() < tn2->getId();
	}

};
#endif NODEPOINTERORDER_H
