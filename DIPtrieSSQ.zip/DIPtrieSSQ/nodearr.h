#ifndef NODEARRAY_H
#define NODEARRAY_H
#include <vector>

using namespace std;

class NodeArray
{
public:
	NodeArray(){arr=new vector<int>;}
	NodeArray(int l){arr=new vector<int>;}
	~NodeArray(){ delete arr;}

	vector<int> *getArray() {return arr;}

	/*long getPos() {return position;}
	void setPos(long p){position =p;}*/


	vector<int> *arr;
	//long position;
};
#endif NODEARRAY_H
