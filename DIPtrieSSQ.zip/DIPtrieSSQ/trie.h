/*----------------------------------------------------------------------
File    : trie.cpp
Contents: gtriejoin
Author  : Lianyin Jiah
Update  : 11/04/2017
----------------------------------------------------------------------*/
#ifndef TRIE_H
#define TRIE_H

#include <set>
#include <map>
#include <unordered_map> //新增包含unordered_map头文件
 //#include "hash.h"
#include <string>
//#include "elem.h"
//#include "query.h"
#include "trienode.h"
#include "data.h"
#include "querynode.h"
#include "similarity.h"
using namespace std;

#define MAX_ELEMENT_COUNT 20000000

//typedef stdext::hash_map<string, TrieNode*, stringhasher> HASH_S;

class Trie
{
public:

    // 声明成员函数
    std::vector<TrieNode*>& getNodesAtDepth(int targetDepth);//新增
    // 其他成员...
    Trie();
    ~Trie();


    void processItems(Transaction *t);
    //void setMinsup(int ms) {minsup = ms;}
    //int grow(int *current, int depth);
    //void ReOrder();
    //int Prune();
    //void setOutput(FILE *of) {out =of;}
    //void print(int *itemset, int il, int *comb, int cl, int support, int spos=0, int depth=0, int *current=0);

    //vector<int>  getSkeletonTree(Query *query);
    void createIndex(Partition *part);
    void partTrieQuery();


    void indexRecord(Transaction *t,int len);
    void process_query(Transaction *t,SimiCache *simCache);
    void process(Transaction *t,SimiCache *simCache);
    void lpFilter_query(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,vector<Candidates *> *allCandidates,SimiCache *simCache);
    void lpFilter(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,vector<Candidates *> *allCandidates,SimiCache *simCache);

    bool verify(Transaction *tran, Transaction *cand, int tranPos,int candPos,int foundoverlap,int overlapthres);
    bool verify_desc(Transaction *tran, Transaction *cand, int tranPos,int candPos,int tranMaxPos,int candMidPos,int foundoverlap,int overlapthres);

    bool verify_ASC_DESC(Transaction *tran, Transaction *cand, int tranLPos,int tranRPos,int candLPos, int candRPos,int foundoverlap,int overlapthres);

    void partTrieJoin(Partition *part);
    void process_map(Transaction *tran, SimiCache *simCache);
    void lpFilter_map(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,map<int,Candidates_map> *allCandidates,SimiCache *simCache);
    void lpFilter_map_query(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,map<int,Candidates_map> *allCandidates,SimiCache *simCache);


    //只考虑第一层查询节点
    void process_query_l1(Transaction *tran, SimiCache *simCache);
    void process_query_l1_prelp(Transaction *tran, SimiCache *simCache);
    void process_query_l1_nolp(Transaction *tran, SimiCache *simCache);
    void process_query_l1_postlp(Transaction *tran, SimiCache *simCache);
    void process_query_l1_depthlp(Transaction *tran, SimiCache *simCache);
    void process_query_l1_lenlp(Transaction *tran, SimiCache *simCache);
    void process_query_l1_noFilter(Transaction *tran, SimiCache *simCache);
    void verify_query_l1_postlp(Transaction *tran,int tranDepth,TrieNode * node,SimiCache *simCache, int start);
    void verify_query_l1_prelp(Transaction *tran,int tranDepth,TrieNode * node,int minLen, int maxLen, SimiCache *simCache);
    void verify_query_l1_nolp(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache);
    void verify_query_l1_depthlp(Transaction *tran,int tranDepth,TrieNode * node,SimiCache *simCache, int start);
    void verify_query_l1_lenlp(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache);
    void verify_query_l1_noFilter(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache);

    void verify_query_l1(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache);

    void process_map_query(Transaction *tran, SimiCache *simCache);
    //vector<int> subSetQuery(Query *query);

    //void traverseFromNode(TrieNode * node,Query *query);
    bool isNodeInQuery(int nodeid,Transaction *sortedt,int priorlen,SimiCache *simCache);

    bool isNodeInQuery_l1(int nodeid,Transaction *sortedt,int priorlen,SimiCache *simCache);
    TrieNode * findNearestAncestor(TrieNode * node,Transaction *t,int priorlen,SimiCache *simCache,int &stride);
    TrieNode* findNearestAncestor_l1(TrieNode * node,Transaction *st,int priorlen,SimiCache *simCache,int &stride);
    TrieNode* findNearestAncestor_l1_ADESC(TrieNode * node,Transaction *st,int tranPos,SimiCache *simCache,int &stride);

    TrieNode* isIDinAncestor(TrieNode * node,int id);

    void addToResult(vector<int> *res, vector<int> *ii);
    //新增：添加depthMap接口函数
    // 新增：获取指定深度的所有节点
    //const vector<TrieNode*>& getNodesByDepth(int targetDepth) const{
     //   static vector<TrieNode*> emptyVector;
     //   auto iter = depthMap.find(targetDepth);
     //   if (iter != depthMap.end()) {
     //       return iter->second;
     //   }
     //   return emptyVector;  // 若不存在该深度，返回空向量
    //}
    static bool depthComparator(const TrieNode* tn1, const TrieNode* tn2) {
        return (tn1->depth < tn2->depth);
    }


    //InvertList* mergeList(InvertList * i1,InvertList * i2);

    static int paircount;
    unsigned int transcount;
    unsigned int processedtrans;
    unsigned int processedelems; //f

    unsigned int occurcount; //o
    unsigned int ancestorpathlen;//l
    unsigned int headerlen;
    unsigned int parentchildrencount;

    unsigned nodes;
    //int totalnode;

    unsigned int words;
    unsigned int totallistnumber;
    unsigned int foundpair;

    int candidateSize;
    int resultSize;
    int nodesaccessed;
    int indexActualSize;  // 统计索引实际大小（倒排列表中所有元素的实际长度之和）

    // 候选集统计
    long long totalCandidatesVerified;  // 传入验证函数的总候选集数目
    long long totalCandidatesPassed;    // 通过验证的候选集数目

    //====新增：统计verify_query_l1_postlp被调用的Trie节点数目====
    long long cnt_call_verify_l1_postlp;

        //====新增：统计祖先链访问的节点数====
    long long ancestorNodesAccessed;
    //====新增：统计查询节点倒排索引中的集合总数====
    long long invlistSetTotal;

    vector<int> result;

    vector<int> lenDepthLBCache;

    int simType;
    double threshold;
    double cThres;
    int candGenType;
    int operType;

    Data *data;

    FILE *out;
    //static int *remap;
    //static set<Element> *relist;

    TrieNode *header[MAX_ELEMENT_COUNT];
    vector<TrieNode *> sLNodes[MAX_ELEMENT_COUNT]; //同标签的节点集

    int maxID;
    int maxElemID;

    TrieNode *queryNode;
    int triePreOrder;
    int filterType;
private:

    //set<Item> header;

    //HASH_S hashheader;

    //HASH_S::iterator it;
    set<TrieNode *,TrieNodeComparator> *root;
    //vector<TrieNode *> *root;
    // key: 深度，value: 该深度的所有节点
    std::unordered_map<int, std::vector<TrieNode*>> depthMap;//新增


};

#endif TRIE_H
