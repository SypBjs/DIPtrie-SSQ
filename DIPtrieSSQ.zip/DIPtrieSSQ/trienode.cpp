#include "trienode.h"

void TrieNode::removeChildren()
{
  //vector<TrieNode *> *nodes = children;
  set<TrieNode *,TrieNodeComparator> *nodes = children;

  if(nodes != NULL)
  {
	  for(set<TrieNode *,TrieNodeComparator>::iterator it = nodes->begin();it != nodes->end(); it++)

		 {
		     (*it)->removeChildren();
		     delete (*it);
		 }
	  delete children;
	  children = NULL;
  }
}
//创建并返回节点的子结点集合指针
set<TrieNode *,TrieNodeComparator> *TrieNode::makeChildren()
{
	if(children==NULL)
		children = new set<TrieNode *,TrieNodeComparator>;
	return children;
}
//初始化成员变量
TrieNode::TrieNode()
{
	nodeID=0;
	parent=NULL;
	index=NULL;
	nodelink=NULL;
	children=NULL;
}
//初始化节点ID和父节点
TrieNode::TrieNode(int id)
{
	nodeID=id;
	parent=NULL;
	index=NULL;
	nodelink=NULL;
	children=NULL;
}
//初始化节点ID、父节点和索引
TrieNode::TrieNode(int id,TrieNode *p)
{
	nodeID=id;
	parent=p;
	index= new NodeArray();
	nodelink=NULL;
	children=NULL;

}

TrieNode::~TrieNode()
{
//	/*if(children)
//		delete children;*/
//	if(nodelink)
//		delete nodelink;
//	/*if(parent)
//		delete parent;*/
//
//	if(index)
//		delete index;


	delete index;
	index = NULL;
	nodelink = NULL;
	parent = NULL;
}

//void TrieNode::AppendIdx(InvertList *idx)
//{
//	if(index == NULL)
//		index = idx;
//	else
//	{
//		idx->setNext(index);
//		index=idx;
//	}
//}
