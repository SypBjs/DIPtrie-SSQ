
#include <stdio.h>
#include "item.h"

//Item_类的构造函数，初始化成员变量
Item_::Item_()
{
  supp = 0;
  parent = 0;
  //nodelink = 0;
  id = 0;
  children = 0;
}

Item_::~Item_()
{}

Item::Item(int s, Item_ *p)
{
  item = new Item_();
  item->id = s;
  item->parent = p;
}

Item::Item(const Item& i)
{
  Item_ *tmp = i.getItem();

  item = new Item_();
  item->id  = tmp->id;
  item->parent = tmp->parent;
  item->children = tmp->children;
  //item->nodelink = tmp->nodelink;
  item->supp = tmp->supp;
}

Item::~Item()
{
  delete item;
}

//创建并返回子结点集合指针
set<Item> *Item::makeChildren() const
{
  if(item->children==0) item->children = new set<Item>;
  return item->children;
}

//递归删除该节点的子结点，及子结点的子结点，并释放子结点的内存
void Item::removeChildren() const
{
  set<Item> *items = item->children;
  for(set<Item>::iterator it = items->begin();it != items->end(); it++) it->removeChildren();
  delete item->children;
  item->children = 0;
}
