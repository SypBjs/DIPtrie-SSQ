#include <iostream>
#include "util.h"
#include "data.h"
#include "dataProcessor.h"
#include <string.h>
//#include "trieindexinfo.h"
#include "trie.h"
#include "partition.h"
#include "timing.h"
#include <unistd.h>
#include <fstream>//包含文件流头文件
#include <string>//字符串操作
#include <stdexcept>//异常处理
#include <sched.h>
#include <cstdlib>
#include <pthread.h>
#include <iomanip>
#include <getopt.h>
using namespace std;
void bindToCPUCore(int core_id) {
    if (core_id < 0) return;

    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(core_id, &cpuset);

    pthread_t current_thread = pthread_self();
    if (pthread_setaffinity_np(current_thread, sizeof(cpu_set_t), &cpuset) != 0) {
        cerr << "Warning: Failed to bind to CPU core " << core_id << endl;
    }
}

//新增：预热函数（执行一次查询以预热CPU缓存和分支预测器）
void warmUp(Trie* trie) {
    trie->partTrieQuery();
}

/*
  we assume that the data has already been preprocessed, if you want to preprocess data,
  please comment this document and uncomment the content of preprocess.cpp.
*/

void printUsage(const char* programName) {
    cout << "Usage: " << programName << " [options]" << endl;
    cout << "Options:" << endl;
    cout << "  -d, --dataset NAME    Specify the dataset name (e.g., msweb, retail, kosarak, tweets)" << endl;
    cout << "  -t, --cthres VALUE    Specify the trie construction threshold cThres (0.6, 0.7, 0.8, 0.9). Default: 0.6" << endl;
    cout << "  -h, --help            Display this help message" << endl;
    cout << endl;
    cout << "Examples:" << endl;
    cout << "  " << programName << " -d msweb " << endl;
    cout << "  " << programName << " --dataset=retail --cthres=0.8" << endl;
    cout << endl;
    cout << "Note on cThres to threshold mapping:" << endl;
    cout << "  cThres=0.6 iterates the threshold over: [0.6, 0.7, 0.8, 0.9, 1.0]" << endl;
}

void getThresholdList(double cThres, double*& thresholds, int& count) {
    static double allThresholds[] = {0.6,0.7, 0.8, 0.9, 1.0};
    static int totalCount = 5;

    int startIndex = -1;
    for (int i = 0; i < totalCount; i++) {
        if (allThresholds[i] >= cThres) {
            startIndex = i;
            break;
        }
    }

    if (startIndex == -1) {
        thresholds = &allThresholds[3];
        count = 1;
    } else {
        thresholds = &allThresholds[startIndex];
        count = totalCount - startIndex;
    }
}

int main(int argc, char *argv[])
{
    struct DatasetConfig {
        const char* name;
        const char* dataPath;
        const char* queryPath;
    };

    DatasetConfig datasets[] = {
    {"msweb",    "datafile_path",    "queryfile_path"},
    {"retail",   "datafile_path",  "queryfile_path"},
    {"kosarak",  "datafile_path","queryfile_path"},
    {"tweets",   "datafile_path",  "queryfile_path"}
};

    int datasetCount = sizeof(datasets) / sizeof(datasets[0]);
    const char* selectedDataset = "kosarak";
    double cThres = 0.6;
    static struct option longOptions[] = {
        {"dataset", required_argument, 0, 'd'},
        {"cthres",  required_argument, 0, 't'},
        {"help",    no_argument,       0, 'h'},
        {0, 0, 0, 0}
    };

    int optionIndex = 0;
    int c;
    while ((c = getopt_long(argc, argv, "d:t:h", longOptions, &optionIndex)) != -1) {
        switch (c) {
            case 'd':
                selectedDataset = optarg;
                break;
            case 't':
                cThres = atof(optarg);
                break;
            case 'h':
                printUsage(argv[0]);
                return 0;
            default:
                printUsage(argv[0]);
                return 1;
        }
    }

    //根据选择的数据集设置文件路径
    char datafile[300];
    char queryfile[300];
    bool datasetFound = false;

    for (int i = 0; i < datasetCount; i++) {
        if (strcmp(datasets[i].name, selectedDataset) == 0) {
            strcpy(datafile, datasets[i].dataPath);
            strcpy(queryfile, datasets[i].queryPath);
            datasetFound = true;
            cout << "========================================" << endl;
            cout << "选择的Dataset: " << selectedDataset << endl;
            cout << "数据文件路径: " << datafile << endl;
            cout << "查询文件路径: " << queryfile << endl;
            break;
        }
    }

    if (!datasetFound) {
        cerr << "错误: 未找到数据集 '" << selectedDataset << "'" << endl;
        cerr << "可用的数据集: ";
        for (int i = 0; i < datasetCount; i++) {
            cerr << datasets[i].name;
            if (i < datasetCount - 1) cerr << ", ";
        }
        cerr << endl;
        printUsage(argv[0]);
        return 1;
    }


    //获取threshold数组
    double* thresholds = nullptr;
    int thresholdCount = 0;
    getThresholdList(cThres, thresholds, thresholdCount);

    cout << "cThres (create trie:): " << cThres << endl;
    cout << "threshold列表: [";
    for (int i = 0; i < thresholdCount; i++) {
        cout << thresholds[i];
        if (i < thresholdCount - 1) cout << ", ";
    }
    cout << "]" << endl;
    cout << "========================================" << endl;

    char resfile[300]="";
    strcat(strcat(resfile, datafile), "_resfile");
    int queryCount =1000;
    int partNum=1;
    int datatype =FLAT;
    int partType = NOPARTITION;
    int simType =JACCARD;
    int filterType = POST;
    double threshold;
    int triePreOrder = PREFASC;
    int candGenType = BULK;
    int operType = QUERY;
    int cpu_core_id = 1;
    bindToCPUCore(cpu_core_id);
    Data *data =  new Data(datafile,datatype);
    data->readData();
    data->getDataInfo();
    data->setLenIndex();
    if(operType == QUERY)
    {
        if(data==nullptr){
            std::cerr<<"Error:data pointer is null!"<<std::endl;
            return 1;
        }

        if(!isFileExist(queryfile)){
            data->generatQuery(queryCount,queryfile);
            if(!isFileExist(queryfile)){
                std::cerr<<"Error:generatQuery failed to create"<<queryfile<<std::endl;
            }
        }
        data->readQuery(queryfile);
    }

    int len = data->vec_trans.size()-1;
    int lastLen =data->vec_trans[len]->length;

    Partition *p = new Partition(data->vec_trans[0]->length,data->vec_trans[0]->length,lastLen);
    int resultCount = 0;

    Trie *trie = new Trie();
    trie->data = data;
    trie->simType = simType;
    trie->filterType = filterType;
    trie->triePreOrder = triePreOrder;
    trie->candGenType = candGenType;
    trie->operType = operType;
    trie->cThres = cThres;

    cout<<"start creating index:"<<endl;
    Timing timings;
    Timing::Interval * indexTime = timings.add("createIndex");
    trie->createIndex(p);
    timings.finish(indexTime);

    long long indexUsec = indexTime->usertime.tv_sec * 1000000LL + indexTime->usertime.tv_usec;
    indexUsec += indexTime->systemtime.tv_sec * 1000000LL + indexTime->systemtime.tv_usec;
    double indexMillis = indexUsec / 1000.0;
    cout << "index build time: " << indexMillis << " ms" << endl;
    cout<<"index created successfully."<<endl;

  for (int tIdx = 0; tIdx < thresholdCount; tIdx++) {
    threshold = thresholds[tIdx];
    trie->threshold = threshold;
    trie->candidateSize=0;
    trie->totalCandidatesVerified = 0;
    trie->totalCandidatesPassed = 0;
    trie->resultSize = 0;
    trie->nodesaccessed = 0;

    trie->ancestorNodesAccessed = 0;
    trie->invlistSetTotal = 0;
    trie->cnt_call_verify_l1_postlp = 0;

    cout << "----------------------------------------" << endl;
    cout << "当前threshold: " << threshold << endl;

    //多次查询取平均值
    const int RUN_COUNT = 1;
    double totalQueryTimeSum = 0.0;

    for (int run = 0; run < RUN_COUNT; ++run) {
        Timing::Interval * queryTime = timings.add("partTrieQuery");
        trie->partTrieQuery();
        timings.finish(queryTime);

        long long runUsec = 0;
        runUsec += queryTime->usertime.tv_sec * 1000000LL + queryTime->usertime.tv_usec;
        runUsec += queryTime->systemtime.tv_sec * 1000000LL + queryTime->systemtime.tv_usec;
        double runMillis = runUsec / 1000.0;
        totalQueryTimeSum += runMillis;

        if (run < RUN_COUNT - 1) {
            trie->result.clear();
            trie->resultSize = 0;
            trie->totalCandidatesVerified = 0;
            trie->totalCandidatesPassed = 0;
        }
    }

    double avgQueryTimeMillis = totalQueryTimeSum / RUN_COUNT;
    cout << "average query time: " << avgQueryTimeMillis << " ms" << endl;
    cout << "result number: " << trie->resultSize << endl;
    cout<<"candidate number (before verification):"<<trie->candidateSize<<endl;  // 候选集数量
    // 新增：候选集验证统计
    cout << "total candidates verified (before Jaccard): " << trie->totalCandidatesVerified << endl;
    cout << "total candidates passed verification: " << trie->totalCandidatesPassed << endl;
    double passRate = trie->totalCandidatesVerified > 0 ? (double)trie->totalCandidatesPassed / trie->totalCandidatesVerified * 100 : 0;
    cout << "verification pass rate: " << fixed << setprecision(2) << passRate << "%" << endl;

        char threshResfile[350];
        strcpy(threshResfile, resfile);
        char threshSuffix[20];
        sprintf(threshSuffix, "_t%.1f", threshold);
        strcat(threshResfile, threshSuffix);
        data->writePairs(threshResfile, trie->result);
        trie->result.clear();
        trie->resultSize = 0;
    }

    cout << "========================================" << endl;
    cout << timings;

    delete trie;
    return 0;
}


