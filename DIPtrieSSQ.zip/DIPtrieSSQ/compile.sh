#!/bin/bash
# 编译脚本 - DIPtrieSSQ

echo "开始编译..."

# 1. 确保脚本在项目根目录下执行
cd "$(dirname "$0")"

# 2. 自动创建 obj 和 bin 目录，如果没有的话
mkdir -p obj bin

# 3. 编译所有源文件 (直接匹配当前目录下所有的 cpp 文件，避免漏掉)
# 如果你有测试文件（如 test.cpp）不想编译，可以用 grep -v 排除
SOURCES=$(ls *.cpp | grep -v "test.cpp")

for file in $SOURCES; do
    filename=$(basename "$file" .cpp)
    echo "编译 $file ..."
    g++ -c "$file" -o "obj/${filename}.o" -I. -std=c++11 -O
    if [ $? -ne 0 ]; then
        echo "编译 $file 失败！"
        exit 1
    fi
done

# 4. 链接所有的 .o 文件
echo "开始链接..."
g++ obj/*.o -o bin/DIPtrieSSQ -lpthread

# 5. 检查是否成功
if [ $? -eq 0 ]; then
    echo "编译完成！可执行文件位于: bin/DIPtrieSSQ"
    echo ""
    echo "使用方法:"
    echo "  ./bin/DIPtrieSSQ -h            # 查看帮助"
    echo "  ./bin/DIPtrieSSQ -d retail # 运行程序"
else
    echo "链接失败！请检查错误信息。"
fi
