
#ifndef DATA_H
#define DATA_H
#include <stdio.h>
#include <set>
#include <vector>
#include "item.h"
//#include "elem.h"
#include "transaction.h"
#include "partition.h"
using namespace std;
class Partition;

class DataInfo
{
public:
	DataInfo(){};
	DataInfo(int count,int totalcount,int max,int min,set<int> terms);
	~DataInfo(){};
	set<int> getDistinctTerms(){return distinctTerms;}

public:
	int transcount;
	int totalelemcount;
	int minlen;
	int maxlen;
	vector<int> distinctLens;
	set<int> distinctTerms;
};

class Data
{
 public:

  Data(char *filename, int t);
  Data(char *datafilename,char *distinctfilename,char *rawfilename, int t=0);
  ~Data();

  vector<Transaction *>  vec_trans;
  vector<Transaction *>  vec_querys;
  Transaction *getNext();
  Transaction *getNext1();
  void readData();
  //void readQuery(vector<Query*> *querys,char *queryfile);
  //void Data::readQuery(vector<Transaction *> *trans,char *queryfile,int includeID);
  Transaction *getNextAsFlat(FILE *fp);

  Transaction *getNextAsFlatWithID(FILE *fp);


  void elemOrder(int type);
  void lengthOrder(int lenType,int lenLexType);

  void outPut(char *dstfile,int type);
 // int readMswebSingleLine(FILE *rawin,int *flag);
  //void getMswebData(FILE *rawin,FILE *out=NULL);
  void getDataInfo();
  void clearQuerys();
  Partition **partition(int partType, int num,int simType, float threshold);
  void uniformPartition(int num);
  void writePairs(char *dstfile, vector<int> &resVec);

  void generatQuery(int querycount,char *queryfile);
  void readQuery(char *queryfile);

  void opendata();

  void close();

  int getProbeLen(int len,int simType, float threshold);
  int getLenNoLessThan(int len);

  void setLenIndex();

 // void addTranToQuery(Transaction * t,vector<Transaction *> *querys,int len,int rules);

//  void selectTrans(vector<Transaction *> *querys,int count,int minlen,int qualifiednum,int rules);

 // void mulitpleTrans(vector<Transaction *> *querys,int countnow,int countfinal);

 // void generatQueryThreshold(vector<Transaction *> *querys,int querycount,char *queryfile,int *threshold,int count);

 // void generatQueryOK(vector<Transaction *> *querys,int querycount,char *queryfile,int *cardinality,int count,int srules,int trules,int includeID);


 // void generateDuplicate(double ratio,char *outfile);

 // void reverseQuery(vector<Transaction *> *querys,char *remapfile,char *newqueryfile,int includeID);
private:
	Transaction *getNextAs();
	Transaction *getNextAsFlat();
	Transaction *getNextAsQuest();
	Transaction *getNextBin();

    void ReOrder(int type);
    void processItems(Transaction *t);




  FILE *in;
  char *datafile;
  char *distinctfile;
  char *rawfile;
  int current;
  int type;
  int transcount;


 // Transaction *trans;


  set<Item> header;
  static int *remap;
  static set<Element> *relist;
public:

  LenIdxEntry **lenIdx;
  DataInfo *info;

};


#endif DATA_H
