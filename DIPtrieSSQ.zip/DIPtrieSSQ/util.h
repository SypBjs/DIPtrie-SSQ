#ifndef UTIL_H
#define UTIL_H
#include   <stdlib.h>
#include   <stdio.h>
#include   <time.h>
//#include "invertlist.h"
#include <time.h>
#include <vector>
#include <algorithm>
//#include "hash.h"
using namespace std;


#define random(x) (rand()%x)
template <typename T>
int binary(T key,T *data,int length)
{
	int low=0, high = length -1;
	int mid;
	if(key>data[high] || key<data[low]) return -1;
	while(low<=high)
	{
		mid = (low + high)/2;
		if(data[mid] == key)
			return mid;
		else if(data[mid]<key)
		{
			low = mid+1;
		}
		else
		{
			high =mid-1;
		}

	}
	return -1;
}

template <typename T>
int binaryWithComparedTimes(T key,T *data,int length,int *comparetimes)
{
	int low=0, high = length -1;
	int mid;
	if(key>data[high] || key<data[low]) return -1;
	while(low<=high)
	{
		mid = (low + high)/2;
		*comparetimes +=1;
		if(data[mid] == key)
		{
			return mid;
		}
		else if(data[mid]<key)
		{
			low = mid+1;
		}
		else
		{
			high =mid-1;
		}

	}
	return -1;
}

template <typename T>
int binaryPointer(T key,T *data,int length)
{
	int low=0, high = length -1;
	int mid;
	if(*key>*data[high] || *key<*data[low]) return -1;
	while(low<=high)
	{
		mid = (low + high)/2;
		if(*data[mid] == *key)
			return mid;
		else if(*data[mid]<*key)
		{
			low = mid+1;
		}
		else
		{
			high =mid-1;
		}

	}
	return -1;
}

template <typename T>
int scanPointer(T key,T *data,int length)
{
	for(int i=0;i<length;i++)
	{
		if(*data[i] == *key)
		{
			return i;
		}
	}
	return -1;

}
int binarygreaterpos(int key,int *data,int length,bool canequlity=true);
int binarysmallerpos(int key,int *data,int length,bool canequlity=true);
int binarygreaterposWithComparedTimes(int key,int *data,int length,int *comparetimes, bool canequlity=false);

//int doublebinary(int key,InvertList *data);

void qsort(int* a,int l,int r);

bool isFileExist(char *fn);

int *getNonRepeat(int setsize,int count);
int *getRandom(int maxval,int count);

void listMerge(vector<int> *v1,vector<int> *v2,vector<int> *v);

typedef enum ElementOrder
{
	LEX_ASC = 0,
	LEX_DESC,
	WORDFRE_ASC,
	WORDFRE_DESC
}ElementOrder;

typedef enum LenOrder
{
	LEN_ASC = 0,
	LEN_DESC
}LenOrder;

typedef enum LenLexOrder
{
    NONE = 0,
	LEN_LEX_ASC,
	LEN_LEX_DESC
}LenLexOrder;
//typedef enum QueryType
//{
//	SUBSET = 0,
//	EQULITY,
//	SUPERSET,
//	SIMILARITY
//}QueryType;

typedef enum IndexType
{
	PROBECOUNT = 0,
	PROBECOUNTOPTMERGE,
	PROBECOUNTSORT,
	TRIEINDEX
}IndexType;

typedef enum OperType
{
	QUERY = 0,
	JOIN
}OperType;

typedef enum TriePrefixOrder
{
	PREFASC = 0,
	PREFDESC
}TriePrefixOrder;

typedef enum DataType
{
	BINARY = 1,
	ASCII,
	FLAT,
	ASCIIBINARY
}DataType;

typedef enum PartitionType
{
    NOPARTITION = 1,
	EQUAL_TRANS,
	EQUAL_ELEMS,
	EQUAL_LENS

}PartitionType;


typedef enum CommonThreshold
{
	TEN =10,
	THIRTY = 30,
	FIFTY=50,
	SEVENTY
}CommonThreshold;

typedef enum ListWhere
{
	LISTINMEMORY,
	LISTNOTINMEMORY
}ListWhere;

typedef enum SimilarityType
{
    OVERLAP,
	JACCARD,
	COSINE,
	DICE,
    HAMMING
}SimilarityType;

typedef enum FilterType
{
    NOP, //无过滤
	NDONLY, //仅节点长度过滤
	PRE,//先长位过滤
	POST,//后长位过滤
    DEPTH,//仅深度过滤
    LENGTH,//仅长度过滤
    NO, //不过滤，直接验证
	MULTI //多层过滤
}FilterType;

typedef enum CandGenType
{
    SCAN=1,
	BULK
}CandGenType;


#endif UTIL_H
