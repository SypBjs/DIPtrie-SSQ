#include "dataProcessor.h"
void DataProcessor::process()
{
    data->elemOrder(eOrder);
    data->lengthOrder(lOrder,llOrder);
}
