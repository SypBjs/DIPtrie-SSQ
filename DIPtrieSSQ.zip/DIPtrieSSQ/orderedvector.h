#ifndef ORDEREDVECTOR_H
#define ORDEREDVECTOR_H
#include <vector>
#include <algorithm>
using namespace std;


//template <typename Container>
//inline void ordered_insert(Container& c,typename Container::value_type const& t);
//
//
//template <typename Container, typename Cmp>
//inline void ordered_insert(Container& c,typename Container::value_type const& t,Cmp cmp);
//
//
//template <typename Container,typename It>
//inline void erase_range(Container& c, std::pair<It, It> const& r);
//
//
//template <typename Container>
//inline void ordered_erase(Container& c,typename Container::value_type const& t);
//
//
//template <typename Container,typename T, typename Cmp>
//inline void ordered_erase(Container& c, T const& t, Cmp cmp);
template <typename Container>
inline void ordered_insert(Container& c,typename Container::value_type const& t)
{
    c.insert(std::upper_bound(c.begin(),c.end(),t),t);
}

template <typename Container, typename Cmp>
inline void ordered_insert(Container& c,typename Container::value_type const& t,Cmp cmp)
{
	c.insert(std::upper_bound(c.begin(),c.end(),t,cmp), t);
}

template <typename Container,typename It>
inline void erase_range(Container& c, std::pair<It, It> const& r)
{
	c.erase(r.first, r.second);
}

template <typename Container>
inline void ordered_erase(Container& c,typename Container::value_type const& t)
{
	erase_range(c, std::equal_range(c.begin(),c.end(), t));
}

template <typename Container,typename T, typename Cmp>
inline void ordered_erase(Container& c, T const& t, Cmp cmp)
{
	erase_range(c, std::equal_range(c.begin(), c.end(), t, cmp));
}
#endif ORDEREDVECTOR_H
