#ifndef SIMILARITY_INCLUDED
#define SIMILARITY_INCLUDED
#include <math.h>
#include "util.h"


class Similarity
{
public:

    //const float kFudgeFactor = .0000001;
    static inline int getMinSize(int len, int simType, double threshold)
    {
        int minSize = 0;
        switch (simType)
        {
        case OVERLAP:
            minSize = (int)threshold;
            break;
        case JACCARD:
            minSize = ceil(len * threshold);
            break;
        case COSINE:
            minSize =ceil(len*threshold*threshold);
            break;
        case DICE:
            minSize= ceil(len*threshold);
            break;
        case HAMMING:
            minSize = len-(int)threshold;
            break;
        default:
            minSize = ceil(len * threshold);
            break;
        }
        //强制约束minSize在[0.len]范围内
        minSize=std::max(0,std::min(minSize,len));
        return minSize;
    }
    static inline int getMaxSize(int len, int simType, double threshold)
    {
        int maxSize = 0;
        switch (simType)
        {
        case JACCARD:
            maxSize = int(len / threshold);
            break;
        case COSINE:
            maxSize =int(len/threshold/threshold);
            break;
        case DICE:
            maxSize= len;
            break;
        case HAMMING:
            maxSize = len + (int)threshold;
            break;
        default:
            maxSize = int(len / threshold);
            break;
        }
        return maxSize;
    }

    static inline int getMinOverlap(int len1, int len2, int simType, double threshold)
    {
        int minoverlap = 0;
        switch (simType)
        {
        case OVERLAP:
            minoverlap = min(len1,len2);
            break;
        case JACCARD:
            minoverlap = (int)(ceil((len1 + len2) * threshold / (1 + threshold)));
            break;
        case COSINE:
            minoverlap = (int)ceil(threshold * sqrt(len1 * len2));
            break;
        case DICE:
            minoverlap= (int)ceil(threshold * (len1 + len2) / 2);
            break;
        case HAMMING:
            if(len1 + len2 > (int)threshold) {
				// the + 1 is there to avoid a float cast and a ceil on the whole term
				minoverlap = (len1 + len2 - (int)threshold + 1) / 2;
			} else {
				minoverlap = 1;
			}
            break;
        default:
            minoverlap = (int)(ceil((len1 + len2) * threshold / (1 + threshold)));
            break;
        }
        return minoverlap;
    }
    static inline int getMaxPrefix(int len, int simType, double threshold)
    {
        return len-getMinSize(len,simType,threshold)+1;
    }
    static inline int getMidPrefix(int len, int simType, double threshold)
    {
        return len-getMinOverlap(len,len,simType,threshold)+1;
    }

    //获得lpfilter的最小下界
    //diff means the difference between qn.level and qn.queryDepth
    static inline int getLPLBound(int len, int simType, double threshold,int diff)
    {
        int lpLowerBound = 0;
        switch (simType)
        {
        case OVERLAP:
            lpLowerBound = (int)threshold+diff;
            break;
        case JACCARD:
            lpLowerBound = ceil(threshold*len + (1+threshold)*diff);
            break;
        case COSINE:
            lpLowerBound = ceil(pow(threshold * sqrt(len)  +sqrt(threshold * threshold*len + 4*diff),2)/4);
            break;
        case DICE:
            lpLowerBound= ceil((threshold * len + 2*diff)/(2-threshold));
            break;
        case HAMMING:
            lpLowerBound= ceil(len-(int)threshold +2* diff);
            break;
        default:
            lpLowerBound = ceil(threshold*len + (1+threshold)*diff);
            break;
        }
        return lpLowerBound;
    }

    //获得lpfilter的最大上界
    //diff means the difference between transaction Depth and queryDepth
    static inline int getLPUBound(int len, int simType, double threshold,int diff)
    {
        int lpUpperBound = 0;
        switch (simType)
        {
        case OVERLAP:
            //lpUpperBound = (int)threshold+diff;
            break;
        case JACCARD:
            lpUpperBound = int((len - (1+threshold)*diff)/threshold);
            break;
        case COSINE:
            lpUpperBound = int((len-2*diff+diff*diff/len)/(threshold*threshold));
            break;
        case DICE:
            lpUpperBound= int((1-threshold/2)*len - diff);
            break;
        case HAMMING:
            //lpUpperBound= int(len-(int)threshold +2* diff);
            break;
        default:
            lpUpperBound = int(threshold*len + (1+threshold)*diff);
            break;
        }
        return lpUpperBound;
    }
    //给定trie深度，获得探测该深度节点时需对应的记录长度的最小下界
    static inline int getDepthLBound(int simType, double threshold,int depth)
    {
        int ldLowerBound = 0;
        switch (simType)
        {
        case OVERLAP:
            ldLowerBound = depth + (int)threshold-1;
            break;
        case JACCARD:
            ldLowerBound = ceil((depth-1)/(1-threshold));
            break;
        case COSINE:
            ldLowerBound = ceil((depth-1)/(1-threshold*threshold));
            break;
        case DICE:
            ldLowerBound= ceil((depth-1)*(2-threshold)/(2-2*threshold));
            break;
        case HAMMING:
            //ldLowerBound= ceil(len-(int)threshold +2* diff);
            break;
        default:
            ldLowerBound = ceil((depth-1)/(1-threshold));
            break;
        }
        return ldLowerBound;
    }



};

class SimiCache
{
public:
    void update(int len,int simType,double threshold,int operType)
    {
        minSize = Similarity::getMinSize(len,simType,threshold);
        maxPrefixLen = Similarity::getMaxPrefix(len,simType,threshold);
        maxSize = Similarity::getMaxSize(len,simType,threshold);
        maxsizePrefixLen=Similarity::getMaxPrefix(maxSize,simType,threshold);
       // midPrefixLen = Similarity::getMidPrefix(len,simType,threshold);

        minOverlap.resize(maxSize + 1);
        for(unsigned int i = minSize; i <= maxSize; ++i)
        {
			minOverlap[i] = Similarity::getMinOverlap(len, i,simType, threshold);
        }
        lpLBound.resize(maxsizePrefixLen);
        lpUBound.resize(maxsizePrefixLen);
        for(unsigned int i = 0; i < maxsizePrefixLen; ++i)
        {
            lpLBound[i] = Similarity::getLPLBound(len, simType, threshold,i);
            lpUBound[i] = Similarity::getLPUBound(len, simType, threshold,i);
        }





//            //lpUBound.resize(midPrefixLen-1);
//            for(unsigned int i = 0; i < maxsizePrefixLen; ++i)
//            {
//                lpUBound[i] = Similarity::getLPUBound(len, simType, threshold,i);
//            }



    }
public:
    int minSize;
    int maxSize;  //here is no use
    vector<int> minOverlap;
    int maxPrefixLen;
    int midPrefixLen;
    int maxsizePrefixLen; // only used in QUERY
    vector<int> lpLBound;
    vector<int> lpUBound; // only used in QUERY
};

#endif // SIMILARITY_INCLUDED
