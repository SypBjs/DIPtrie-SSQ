#ifndef TRIENODE_H
#define TRIENODE_H
#include <stdio.h>
#include <set>
#include <vector>
//#include "invertarray.h"
//#include "invertsortedarray.h"
#include "nodearr.h"
//#include "invertlist.h"
//#include "invertarraywithtranlen.h"
using namespace std;
class TrieNodeComparator;


class TrieNode
{
public:
	TrieNode();
	TrieNode(int id);
	TrieNode(int id,TrieNode *p);
	int getId() const {return nodeID;}
	void setId(int id){nodeID=id;}

	//vector<TrieNode *> *getChildren() const {return children;}

	set<TrieNode *,TrieNodeComparator> *getChildren() const {return children;}

	NodeArray *getIndex() const {return index;}
	void setIndex(NodeArray * idx){index=idx;}

	TrieNode *getParent() {return parent;}
	TrieNode *getNext() const {return nodelink;}
	void setNext(TrieNode *node) {nodelink = node;}
	//void AppendIdx(InvertList *idx);

	//vector<TrieNode *> *makeChildren();
	set<TrieNode *,TrieNodeComparator> *makeChildren();
	~TrieNode();

	void removeChildren();
	bool operator < (const TrieNode &i) const {return getId() < i.getId();}
	bool operator > (const TrieNode &i) const {return getId() > i.getId();}
	bool operator == (const TrieNode &i) const {return getId() == i.getId();}

	/*bool operator < (const TrieNode *i) const {return this->getId() < i->getId();}
	bool operator > (const TrieNode *i) const {return this->getId() > i->getId();}
	bool operator == (const TrieNode *i) const {return this->getId() == i->getId();}*/
public:
	int depth;
	//long position;

	int nodeID;
	//char *label;
	//int support;
	//InvertList *index;
	//InvertArray *index;
	NodeArray *index;
	TrieNode *nodelink;
	TrieNode *parent;
	int lowerLen;
	int upperLen;

	//vector<TrieNode *> *children;
	set<TrieNode *,TrieNodeComparator> *children;

};
class TrieNodeComparator {
public:
    bool operator()(const TrieNode* tn1, const TrieNode* tn2) const {
        return (tn1->nodeID < tn2->nodeID);
    }
};



#endif TRIENODE_H
