#ifndef ITEM_H
#define ITEM_H
#include <set>
#include <vector>
//#include "invertarray.h"
//#include "invertlist.h"

using namespace std;

class Item;

class Item_
{
 public:

  Item_();
  ~Item_();


  int id;
  int supp;

  set<Item> *children;

  Item_ *parent;
  //InvertList *nodelink;
};

class Item
{
 public:
  Item(int s, Item_ *p);
  Item(const Item& i);
  ~Item();
  int getId() const {return item->id;}
  int getSupport() const {return item->supp;}

  set<Item> *getChildren() const {return item->children;}
  set<Item> *makeChildren() const;

  Item_ *getItem() const {return item;}
  /*InvertList *getNext() const {return item->nodelink;}
  void setNext(InvertList *i) const {item->nodelink = i;}*/
  bool isFrequent(int ms) const {return item->supp >= ms;}
  void Increment(int i=1) const {item->supp += i;}

  void removeChildren() const;

  bool operator< (const Item &i) const {return getId() < i.getId();}

private:
 Item_ *item;
};
#endif ITEM_H
