#ifndef QUERYNODE_H
#define QUERYNODE_H

class QueryNode
{
public:
    QueryNode()
    {
        isFiltered =false;
        candidateStart = NULL;
        diff = 0;
    }
    QueryNode(int depth)
    {
        isFiltered =false;
        candidateStart = NULL;
        queryDepth = depth;
    }
    QueryNode(int depth,int diff)
    {
        isFiltered =false;
        candidateStart = NULL;
        queryDepth = depth;
        this->diff = diff;
    }
public:
    int diff;
    int queryDepth;
    bool isFiltered;
    int *candidateStart;
    int candCount; // only used in QUERY
    //int candidateEnd;
    //为每一个查询深度为1的候选节点，构造一个候选集vector和一个排除vector。
    //candidatesPos表示本查询节点对应的候选集和排除集是哪一个
    int candidatesPos;
};

class Candidates
{
public:
    Candidates(int size)
    {
        cands = new vector<int>(size);
        excludes = new vector<int>();
        queryDepth = 1;  //暂时未考虑不同深度节点对候选集的强化，验证时仍需从查询深度为1的节点开始
    }

    ~Candidates()
    {
       delete cands;
       delete excludes;
    }
public:
    vector<int> * cands; //we can also not use this vector, instead just sign on nil

    vector<int> * excludes;
    int tranDepth;
    int trieDepth;
    int queryDepth;
};


//对PREFASC而言，仅需考虑lastTranDepth一个属性
//对PREFDESC而言，需考虑firstTranDepth，lastTranDepth,trieDepth三个属性，因为我们需要前后两段验证。
class Candidates_map
{
public:
    Candidates_map(){}

    Candidates_map(int tranDepth,int trieDepth,int queryDepth)
    {
       // this->firstTranDepth = tranDepth;
        this->lastTranDepth = tranDepth;
        this->trieDepth = trieDepth;
        this->queryDepth = queryDepth;
    }
public:
    //int firstTranDepth;//对PREFDESC而言，需存储第一次匹配的位置，用于记录后半段的验证
    int lastTranDepth;//对PREFASC而言，本属性存储最后一个匹配的元素位置，用于记录后半段的验证；对PREFDESC而言，存储最后一次匹配的位置，用于记录前半段的验证
    int trieDepth; //对PREFASC而言，本属性存储最后一个匹配的元素对应的trie深度；对PREFDESC而言，存储第一次匹配位置对应的trie深度。
    int queryDepth;
};

#endif // QUERYNODE_H
