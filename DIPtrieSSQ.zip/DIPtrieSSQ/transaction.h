#ifndef TRANSACTION_INCLUDED
#define TRANSACTION_INCLUDED

#include <stdio.h>
#include <set>
#include <vector>
using namespace std;


class Element
{
 public:
  Element(int s, int i) : support(s), id(i){}

  int support;
  int id;
  bool operator< (const Element  &e) const {return support < e.support;}
};



class Transaction
{
 public:

  Transaction(int l) : length(l) {t = new int[l];}
  Transaction(const Transaction &tr);
  ~Transaction(){delete t;}


  int id;

  int length;
  int *t;
  Transaction *next;
};

class Sortedtrans
{
public:
	Sortedtrans(Transaction* t) : tran(t){}

	Transaction* tran;

	bool operator< (const Sortedtrans  &s) const {return tran->length < s.tran->length;}
};

#endif // TRANSACTION_INCLUDED
