#ifndef INVERTSORTEDARRAY_H
#define INVERTSORTEDARRAY_H
#include <vector>

using namespace std;

class InvertSortedArray
{
public:
	InvertSortedArray(){arr = new vector<int>;}
	InvertSortedArray(int l){arr = new vector<int>;}
	~InvertSortedArray(){ delete arr;}

	vector<int> *getArray() {return arr;}

	long getPos() {return position;}
	void setPos(long p){position =p;}

private:
	vector<int> *arr;
	long position;
};
#endif INVERTSORTEDARRAY_H
