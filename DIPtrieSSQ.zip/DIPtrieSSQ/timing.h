#ifndef TIMING_H
#define TIMING_H


#include <sys/time.h>
#include <sys/resource.h>
#include <vector>
#include <string>
#include <stdio.h>

class Timing {
	public:
		struct Interval {
			std::string descriptor;
			struct timeval usertime;
			struct timeval systemtime;
			Interval(const std::string & descriptor) : descriptor(descriptor) {}
		};
	protected:
		std::vector<Interval*> intervals;

	public:
		Interval * add(const std::string & descriptor);
		void finish(Interval * interval);
		~Timing();
		friend std::ostream & operator<<(std::ostream & os, const Timing & timing);

};


#endif // TIMING_H_INCLUDED
