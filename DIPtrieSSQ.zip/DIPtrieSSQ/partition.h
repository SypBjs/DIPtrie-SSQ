#ifndef PARTITION_INCLUDED
#define PARTITION_INCLUDED
#include <string>
#include <vector>
#include <iostream>
#include <algorithm>
using namespace std;
#include "data.h"
#include "transaction.h"

class LenIdxEntry
{
public:
    LenIdxEntry(int s){start = s;}
   // void setSize(int s) {size = s;}

    int start;
    int size;
};

class Partition
{
public:
    Partition(){};
    Partition(int aStrartLen, int pStartLen, int eLen )
    {
        accessStartLen = aStrartLen;
        probeStartLen = pStartLen;
        endLen = eLen;
        startTransactionID=-1;//新增字段
        endTransactionID=-1;//新增
    }

    int accessStartLen;
    int probeStartLen;
    int endLen;
    int startTransactionID;//新增起始事务ID
    int endTransactionID;//新增结束事务ID
};

#endif // PARTITION_INCLUDED
