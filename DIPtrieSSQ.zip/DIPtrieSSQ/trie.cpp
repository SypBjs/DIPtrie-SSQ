/*----------------------------------------------------------------------
File    : trie.cpp
Contents: gtriejoin
Author  : Lianyin Jia
Update  : 11/04/2017
----------------------------------------------------------------------*/

#include <iostream>
#include <stdio.h>

#include "data.h"
#include "string.h"
#include "trie.h"
#include <algorithm>
#include "util.h"
//#include "invertlist.h"
#include "orderedvector.h"
#include "nodepointerorder.h"
#include <unordered_map> depthMap

using namespace std;
int Trie::paircount =0;
//unordered_map<int,vector<TrieNode*>> depthMap;
//int *Trie::remap = 0;
//set<Element> *Trie::relist = 0;
//Trie的构造函数，初始化Trie的根节点、计数器、头指针等成员变量
Trie::Trie()
{
    //root = new vector<TrieNode *>;
    root = new set<TrieNode*,TrieNodeComparator>;//为根节点分配内存

    nodes = 0;//节点计数器初始化

    transcount =0;//事务（集合）计数器
    processedtrans =0;//已处理的事务计数器
    words=0;
    //其他原有初始化......
    cnt_call_verify_l1_postlp = 0;
    totallistnumber=0;
    foundpair =0;//找到的配对数量

    occurcount=0; //o出现次数
    ancestorpathlen=0;//l祖先路径长度计数
    headerlen=0;
    parentchildrencount=0;//父子数

    for(int i =0; i<MAX_ELEMENT_COUNT; i++)
    {
        header[i]=NULL;
    }

    queryNode = new TrieNode();//为查询节点分配内存
    nodesaccessed=0;//访问的节点计数器初始化为0

    ancestorNodesAccessed = 0;
    invlistSetTotal = 0;

    //nodesgot = 0;
    resultSize =0;//结果集大小计数
    candidateSize = 0;//候选集大小数

    // 候选集统计初始化
    totalCandidatesVerified = 0;  // 传入验证函数的总候选集数目
    totalCandidatesPassed = 0;    // 通过验证的候选集数目

    maxID =0;
    maxElemID =0;

    //singlepath=true;
}

//析沟函数，释放内存
Trie::~Trie()
{
    //j指集合id编号，此处从0-10，对所有集合构造Trie
    set<TrieNode*,TrieNodeComparator>::iterator it;
    for(it = root->begin(); it != root->end(); it++)
        (*it)->removeChildren();
    delete root;
    root = NULL;

    delete queryNode;
    //fclose(out);
}

//基于给定的分区信息，创建Trie树索引的函数，将数据插入到Trie树中
//1.获取集合起始ID和结束ID；2.计算每个集合的最大前缀；3.调用indexRecord函数将各集合前缀插入到Trie中
//关键：集合数量、前缀、记录索引信息、对节点排序；为后续基于trie的查询作准备
/*
void Trie::createIndex(Partition *part)
{
//索引构建范围
//第一个数据集ID，从0开始
    int probeStartID =data->lenIdx[part->probeStartLen]->start;
    cout<<"probeStartID:"<<probeStartID<<endl;
    //int accessStartID = data->lenIdx[part->accessStartLen]->start;
//最后一个数据集ID
//经调试：该行有失误
    int accessEndID = data->lenIdx[part->endLen]->start+ data->lenIdx[part->endLen]->size -1;
    cout<<"accessEndID:"<<accessEndID<<endl;
    cout<<"this partition size:"<<accessEndID-probeStartID<<endl;
    int maxPrefixLen;
    //遍历事务，构建trie前缀树。计算前缀并记录索引
    for(int i =probeStartID; i <=accessEndID; i++)
    {
        Transaction *tran = data->vec_trans[i];
        if(tran==NULL){
            cout<<"NULL at i="<<i<<endl;
            exit(1);
        }
        if(tran->length < 0){
            cout<<"Error"<<endl;
            exit(1);
        }
        maxPrefixLen = Similarity::getMaxPrefix(tran->length,simType,cThres);
        //cout<<"maxElemID1"<<maxElemID<<endl;
        indexRecord(tran,maxPrefixLen);
        //cout<<"maxElemID2"<<maxElemID<<endl;
        //下列if语句开始报错
        if(tran->t[tran->length-1] > maxElemID) maxElemID =tran->t[tran->length-1]; //maxElemID 存储最大的元素
    }
    //对Trie节点按深度便利编号
    for(int j=1;j<= maxElemID;j++)
    {
       sort(sLNodes[j].begin(),sLNodes[j].end(),depthComparator);
       //cout<<"sLNodes:"<<sLNodes[j]<<endl;
    }

}
*/

void Trie::createIndex(Partition *part)
{
    //SimiCache simCache;
    //int lastprobesize = 0;

    int probeStartID =data->lenIdx[part->probeStartLen]->start;
    //int accessStartID = data->lenIdx[part->accessStartLen]->start;
    int accessEndID = data->lenIdx[part->endLen]->start+ data->lenIdx[part->endLen]->size -1;

    int maxPrefixLen;
    for(int i =probeStartID; i <=accessEndID; i++)
    {
        Transaction *tran = data->vec_trans[i];
        maxPrefixLen = Similarity::getMaxPrefix(tran->length,simType,cThres);
        indexRecord(tran,maxPrefixLen);
        if(tran->t[tran->length-1] > maxElemID) maxElemID =tran->t[tran->length-1]; //maxElemID 存储最大的元素
    }

    for(int j=1;j<= maxElemID;j++)
    {
       sort(sLNodes[j].begin(),sLNodes[j].end(),depthComparator);
    }
}

//处理部分Trie查询，对分区内的Trie查询处理
//Trie树的查询函数，用于对查询集进行匹配--分区
//1.初始化最大前缀长度；2.根据候选生成过滤类型调用不同过滤函数进行查询处理
void Trie::partTrieQuery()
{
    //maxPrefixLen represents the maximum detection depth of trie
    //depth than this value will be filtered directly.
    int lastprobesize = 0;//maxquerylen=0上一次查询集合的长度
    SimiCache simCache;
    //i:遍历查询集时：从第一个集合第一个元素开始编号，到最后一个集合的最后一个元素编号完成，从0开始编号，而不是以集合为单位编号
    for(int i=0; i< data->vec_querys.size(); i++)//遍历查询集：一个元素一个元素遍历，而不是一个集合一个集合遍历
    {
        //make querydata sets:依次取dataquery中的集合，一条一条的取，一条一条的判断
        Transaction *query =data->vec_querys[i];
        //cout << "maxPrefixLen: " << simCache.maxPrefixLen << endl;

        if(query->length != lastprobesize)//如果当前查询集的长度与上一次不同
        {
            lastprobesize = query->length;//更新上一次查询集的长度
            simCache.update(query->length,simType,threshold,operType);
        }

        switch (filterType)
        {
            case NO://直接验证
                process_query_l1_noFilter(query,&simCache);
                break;
            case LENGTH:
                process_query_l1_lenlp(query,&simCache);//长度过滤
                break;
            case DEPTH:
                process_query_l1_depthlp(query,&simCache);//深度过滤
                break;
            case NOP://深度+长度
                process_query_l1(query,&simCache);
                break;
            case NDONLY://深度+长度
                process_query_l1_nolp(query,&simCache);
                break;
            case PRE:
                process_query_l1_prelp(query,&simCache);//前缀过滤
                break;
            case MULTI:
                process_query(query,&simCache);//
                break;
            default:
                process_query_l1_postlp(query,&simCache);//长位过滤
                break;
        }

    }

}

/*
    int lastprobesize = 0; //maxquerylen-0上一次查询集合的长度
    SimiCache simCache;

    cout << "=== start query ===" << endl;
    cout << "queryfile size: " << data->vec_querys.size() << endl;
    cout << "datafile size: " << data->vec_trans.size() << endl;
    cout << "element range:0 to " << MAX_ELEMENT_COUNT << endl;
    // 数据一致性验证
//    validateDataConsistency();

    for(int i=0; i< data->vec_querys.size(); i++)
    {
        Transaction *query = data->vec_querys[i];

        // 安全检查：确保查询指针有效
        if(!query) {
            cout << "error：query " << i << " is nulltr,breake" << endl;
            continue;
        }

        // 特别关注第596和597条查询
        if(i == 596 || i == 597) {
            cout << "=== solve query " << i << " ===" << endl;
            cout << "query ID: " << query->id << endl;
            cout << "query length: " << query->length << endl;
            cout << "query momment: ";
            for(int j=0; j<query->length; j++) {
                cout << query->t[j] << " ";
            }
            cout << endl;
        }

        // 关键修改：检测查询类型并正确处理
        Transaction *processingData = query;

        // 如果查询长度是1，可能是ID，需要映射到实际数据
        if(query->length == 1) {
            int potentialId = query->t[0];

            // 检查这个值是否在数据记录的有效ID范围内
            if(potentialId >= 0 && potentialId < data->vec_trans.size()) {
                processingData = data->vec_trans[potentialId];

                if(i == 596 || i == 597) {
                    cout << "mapping ID " << potentialId << " to effective data:" << endl;
                    cout << "real data ID: " << processingData->id << endl;
                    cout << "real data length: " << processingData->length << endl;
                    cout << "real data momment: ";
                    for(int j=0; j<processingData->length; j++) {
                        cout << processingData->t[j] << " ";
                    }
                    cout << endl;
                }
            } else {
                if(i == 596 || i == 597) {
                    cout << "query momment is not valid ID,use query data" << endl;
                }
            }
        }

        // 使用实际数据的长度更新simCache
        if(processingData->length != lastprobesize)
        {
            lastprobesize = processingData->length;
            simCache.update(processingData->length, simType, threshold, operType);

            if(i == 596 || i == 597) {
                cout << "更新simCache: length=" << processingData->length
                     << ", maxPrefixLen=" << simCache.maxPrefixLen << endl;
            }
        }

        // 在处理前检查数据的有效性
        if(processingData->length <= 0) {
            cout << "error：data length invalid,skip query " << i << endl;
            continue;
        }

        // 检查所有元素是否在sLNodes范围内
        bool validData = true;
        for(int j=0; j<processingData->length; j++) {
            if(processingData->t[j] < 0 || processingData->t[j] >= sLNodes.size()) {
                cout << "error：element " << processingData->t[j]
                     << " more sLNodes range [0, " << sLNodes.size()-1 << "]" << endl;
                cout << "query index: " << i << ",index: " << j << endl;
                validData = false;
                break;
            }
        }
        if(!validData) {
            continue; // 跳过无效数据
        }

        // 原有的switch结构保持不变
        switch (filterType)
        {
            case NOP:
                process_query_l1(processingData, &simCache);
                break;
            case NDONLY:
                process_query_l1_nolp(processingData, &simCache);
                break;
            case PRE:
                process_query_l1_prelp(processingData, &simCache);
                break;
            case MULTI:
                process_query(processingData, &simCache);
                break;
            default:
                process_query_l1_postlp(processingData, &simCache);
                break;
        }

        // 进度显示
        if((i+1) % 100 == 0) {
            cout << "precessed " << (i+1) << "/" << data->vec_querys.size() << " 个查询" << endl;
        }
    }

    cout << "=== query finish ===" << endl;

}
// 数据一致性验证函数
void Trie::validateDataConsistency()
{
    cout << "=== verify data consistency ===" << endl;
    cout << "sLNodes size: " << sLNodes.size() << endl;
    cout << "datafile size: " << data->vec_trans.size() << endl;
    cout << "queryfile size: " << data->vec_querys.size() << endl;

    int invalidIDCount = 0;
    int invalidElementCount = 0;
    int idQueries = 0;

    // 检查所有查询记录
    for(int i = 0; i < data->vec_querys.size(); i++) {
        Transaction* query = data->vec_querys[i];

        if(!query) {
            cout << "error：query " << i << " is nulltr" << endl;
            continue;
        }

        // 特别关注第596和597条查询
        if(i == 596 || i == 597) {
            cout << "verify query " << i << ": length=" << query->length << endl;
        }

        // 如果查询长度为1，检查是否是ID
        if(query->length == 1) {
            int dataId = query->t[0];

            if(dataId >= 0 && dataId < data->vec_trans.size()) {
                idQueries++;
                // 检查映射后的实际数据
                Transaction* actualData = data->vec_trans[dataId];
                if(!actualData) {
                    cout << "error：query " << i << " mapping data is nulltr" << endl;
                    invalidIDCount++;
                } else {
                    // 检查实际数据的元素
                    for(int j = 0; j < actualData->length; j++) {
                        if(actualData->t[j] < 0 || actualData->t[j] >= sLNodes.size()) {
                            invalidElementCount++;
                            if(invalidElementCount <= 5) { // 只显示前5个错误
                                cout << "warning：query " << i << " maping data element "
                                     << actualData->t[j] << " more than sLNodes range" << endl;
                            }
                        }
                    }
                }
            } else {
                // 不是有效ID，检查元素本身
                if(query->t[0] < 0 || query->t[0] >= sLNodes.size()) {
                    invalidElementCount++;
                    cout << "warning：query " << i << " of elements "
                         << query->t[0] << " more than sLNodes range" << endl;
                }
            }
        } else {
            // 多元素查询，检查所有元素
            for(int j = 0; j < query->length; j++) {
                if(query->t[j] < 0 || query->t[j] >= sLNodes.size()) {
                    invalidElementCount++;
                    if(invalidElementCount <= 5) {
                        cout << "warning：query " << i << " of elements"
                             << query->t[j] << " more than sLNodes range" << endl;
                    }
                }
            }
        }
    }

    cout << "verify rusult：" << endl;
    cout << "  ID query nummber: " << idQueries << endl;
    cout << "  invalid element nummber: " << invalidElementCount << endl;

    if(invalidElementCount > 0) {
        cout << "warning：finding " << invalidElementCount << " out-of-scope elements exist,as they may cause a segmentation fault and crash the program." << endl;
    } else {
        cout << "all data is within the valid range." << endl;
    }
}
*/
//对分区内集合域进行连接处理
//1.初始化缓存和前缀
void Trie::partTrieJoin(Partition *part)
{
    SimiCache simCache;
    int lastprobesize = 0;

    int probeStartID =data->lenIdx[part->probeStartLen]->start;
    int accessStartID = data->lenIdx[part->accessStartLen]->start;
    int accessEndID = data->lenIdx[part->endLen]->start+ data->lenIdx[part->endLen]->size -1;

    int midPrefixLen;
    for(int i =probeStartID; i < accessStartID; i++)
    {
        Transaction *tran =data->vec_trans[i];

        if(lastprobesize != tran->length)
        {
            lastprobesize = tran->length;
            midPrefixLen = Similarity::getMidPrefix(tran->length,simType,threshold);
        }
        indexRecord(tran,midPrefixLen);
    }

    for(int i =accessStartID; i <= accessEndID; i++)
    {
        int reclen =data->vec_trans[i]->length;

        if(lastprobesize != reclen)
        {
            lastprobesize = reclen;
            simCache.update(reclen,simType,threshold,operType);
        }
        //process(data->vec_trans[i],&simCache);
        if(candGenType==SCAN)
            process_map(data->vec_trans[i],&simCache);
        else
            process(data->vec_trans[i],&simCache);
    }

}
//将集合域中的集合插入到Trie中
//1.根据前缀遍历确定每个集合的起始和结束位置
//2.遍历集合前缀，创建Trie树节点
//3.将集合ID插入到节点索引中
//4.递归创建子节点
void Trie::indexRecord(Transaction *t,int len)
{
    //防止空指针和无效长度
    if(t==NULL||len<=0) return;//新增
    //初始索引
    int i=(triePreOrder==PREFASC)?0:(len-1);//新增
    //vector<TrieNode *>* trienodes = root;
    set<TrieNode*,TrieNodeComparator>* trienodes = root;
    set<TrieNode*,TrieNodeComparator>::iterator it;
    TrieNode *current = NULL;
        // 检查i是否越界（核心修正）
    if ((triePreOrder == PREFASC && i >= len) ||//新增
        (triePreOrder != PREFASC && i < 0)) {//新增
    }

    int elem = t->t[i]; // 当前元素ID，新增
        // 检查elem是否合法（如非负）
    if (elem < 0) {//新增
        cout << "Error: invalid element ID " << elem << " at i=" << i << endl;
    }
     //}
    int depth = 0;
    int start=0, end = len-1;
    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = len-1;
    }
    else
    {
        start = len-1;
        end = 0;

    }
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if(i > end)
                break;
        }
        else
        {
            if( i < end)
                break;

        }
        depth++;
        //TrieNode *tn = NULL;
        //测试
        //cout<<"Accessing t->["<<i<<"],len="<<len<<endl;
        queryNode->setId(t->t[i]);
        it = trienodes->find(queryNode);
        if(it == trienodes->end())
        {
            //tn = new TrieNode(t->t[i], current);
            it = trienodes->insert(new TrieNode(t->t[i], current)).first;
            (*it)->lowerLen = t->length;
            sLNodes[t->t[i]].push_back(*it); //sLNodes用于存储同标签的节点

            (*it)->setNext(header[t->t[i]]);
            (*it)->depth = depth;
            header[t->t[i]] = (*it);
            nodes++;
            //新增:depthMap,到*it结束
            //将节点加入对应深度的列表中
            //为减少扩容开销，提前预留空间
            if(depthMap[depth].size()%100==0){//新增
                depthMap[depth].reserve(depthMap[depth].size()+100);
            }
            depthMap[depth].push_back(*it);
        }
        (*it)->getIndex()->getArray()->push_back(t->id);
        indexActualSize++;  // 统计：每添加一个事务ID到倒排列表，计数+1
        (*it)->upperLen = t->length;
        if(triePreOrder == PREFASC)
        {
            if(i !=len-1)
            {
                current = *it;
                trienodes = (*it)->makeChildren();
            }
            i ++;
        }
        else
        {

            if(i !=0)
            {
                current = *it;
                trienodes = (*it)->makeChildren();
            }
            i--;
        }

    }
}
// 新增：获取指定深度的所有节点
vector<TrieNode*>& Trie::getNodesAtDepth(int targetDepth) {
    static vector<TrieNode*> emptyVector;
    auto iter = depthMap.find(targetDepth);
    if (iter != depthMap.end()) {
        return iter->second;
    }
    return emptyVector;  // 若不存在该深度，返回空向量
}

//处理基于映射的事务，使用map进行集合处理，用于生成候选集和验证
//1.根据前缀顺序确定每个集合的起始和结束位置
//2.遍历集合前缀，找到对应的Trie节点
//3.调用lpFilter_map函数进行候选集过滤
//4.根据候选集验证，匹配结果添加到结果集
void Trie::process_map(Transaction *tran, SimiCache *simCache)
{

    int start, end;//查询起始位置和结束位置
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;//节点映射表
    if(triePreOrder == PREFASC)//若Trie树的前缀为升序
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else//前缀为降序(还不完善)
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    map<int,Candidates_map> allCandidates;
//    //vector<vector<int> *> allExcludes;
//
//    if(tran->id == 10135)
//    {
//        k++;
//    }
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if(i > end)
                break;
        }
        else
        {
            if( i < end)
                break;
        }
        TrieNode * node = header[tran->t[i]];
        while(node)
        {
            QueryNode qnode;

            if(i == start)
            {
                qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                lpFilter_map(i,node,&qnode,NULL,&allCandidates,simCache);
            }
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor(node,tran,i,simCache, stride);
                if(ancestornode)
                {
                    QueryNode parentNode = nodeMap[ancestornode];
                    //过滤传播机制（子树过滤）:父节点被过滤，则所有子节点均被过滤
                    if(parentNode.isFiltered == true)
                    {
                        qnode.isFiltered = true;
                        //  qnode->queryDepth = parentNode->queryDepth +1;
                    }
                    else
                    {
                        qnode.queryDepth = parentNode.queryDepth +1;
                        qnode.diff = parentNode.diff + stride;//diff仅对PREFDESC有效
                        lpFilter_map(i,node,&qnode,&parentNode,&allCandidates,simCache);

                    }
                }
                else
                {
                    //the first layer query node
                    qnode.queryDepth = 1;
                    lpFilter_map(i,node,&qnode,NULL,&allCandidates,simCache);
                }

            }
            nodeMap[node] = qnode;
            node = node->getNext();
            nodesaccessed++;
        }
        //k++;
        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }
    }

//    for(map<TrieNode *,QueryNode *>::iterator it=nodeMap.begin();it!=nodeMap.end();it++)
//    {
//        delete it->second;
//    }

    if(operType == JOIN)
        indexRecord(tran,simCache->midPrefixLen);

    int count = allCandidates.size();
    //验证候选集，其中统一过滤排除掉的集合
    for(map<int,Candidates_map>::iterator it= allCandidates.begin(); it!=allCandidates.end(); it++)
    {
        int id = it->first;
//        if(id==5420)
//        {
//            int k =0;
//        }
        //此处需计算索引的记录而非当前访问的记录的中等前缀
        int candMidPreLen = Similarity::getMidPrefix(data->vec_trans[id]->length,simType,threshold);
        //需要注意tranDepth从0或前缀减1位置开始，而trieDepth和queryDepth都从1开始
        int lastTranDepth = it->second.lastTranDepth;
        int overFounded = it->second.queryDepth;
        int trieDepth = it->second.trieDepth;
        Transaction *candTran = data->vec_trans[id];
        int tranStart, candStart;

        if(triePreOrder == PREFASC)
        {
            if(candTran->t[candMidPreLen-1] > tran->t[simCache->maxPrefixLen-1])
            {
                tranStart = simCache->maxPrefixLen;
                candStart = trieDepth;
            }
            else
            {
                tranStart = lastTranDepth+1;
                candStart = candMidPreLen;
            }

        }
        else
        {

            if(candTran->t[candMidPreLen-1]>tran->t[simCache->maxPrefixLen-1])
            {
                tranStart = simCache->maxPrefixLen;
                candStart = candMidPreLen - trieDepth +1;
            }
            else
            {
                tranStart = lastTranDepth+1;
                candStart = candMidPreLen;
            }


        }

        if(verify(tran,candTran,tranStart,candStart,overFounded,simCache->minOverlap[candTran->length]))
        {
            resultSize++;
            result.push_back(tran->id);
            result.push_back(candTran->id);
            //cout<<tran->id<<" "<<candTran->id<<endl;
        }


    }

}

//使用lpFilter_map过滤获得候选集和排除集。注：前缀是升序还是降序
//1.计算每个节点的长度下界；
//2.若节点的最大长度小于下界，则过滤该节点；
//3.找到第一个满足长度下界的集合ID位置；
//4.根据查询深度进行不同的处理，生成候选集并进行过滤<节点深度过滤？？>
void Trie::lpFilter_map(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn, map<int,Candidates_map> *candMap,SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    int rightMostID = (*nil)[nil->size()-1];
    int lenLBound;
    if(triePreOrder == PREFASC)
    {
        lenLBound = simCache->lpLBound[node->depth - qn->queryDepth];
    }
    else
    {
        lenLBound = simCache->lpLBound[qn->diff];
    }

    //如果节点的nil中最右的节点长度小于lpFilter的条件，可安全过滤整个节点及所有孩子查询节点
    if(data->vec_trans[rightMostID]->length < lenLBound)
        qn->isFiltered = true;
    else
    {
        //此处调用getProbeLen方法是因为某些长度对应的记录可能为空，
        //startIDLBound表示大于等于lenLBound的且不为空的记录ID的起始位置。

        int startIDLBound = data->lenIdx[data->getLenNoLessThan(lenLBound)]->start;

        //nilStartPos表示中地一个大于等于startIDLBound的位置，也即是满足lpFilter的起始位置
        int nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);
//        //整个列表都不满足条件
//        if(nilStartPos == -1 )
//        {
//            qn->isFiltered = true;
//            return;
//        }
        qn->candidateStart = &(*nil)[nilStartPos];
        if(qn->queryDepth ==1) //对查询深度为1的节点，构造初始候选集
        {
            for(int i=nilStartPos; i<=nil->size()-1; i++)
            {
//                int p = (*nil)[i];
//                if(p==9848)
//                    p=9848;
                (*candMap)[(*nil)[i]]= Candidates_map(tranDepth,node->depth,1);
            }

        }
        else
        {
            //对查询深度不等于1的查询节点，获得该节点所过滤的集合，存储在excludes中
            //过滤的基本思想是：父查询节点候选集起点元素到子节点反向列表的映射 到本查询节点的候选集起点元素之间的所有元素为本节点过滤的元素

            //nilStartPos==0 means no unqualifying IDs to be removed.
            if(nilStartPos!= 0 && *(parentQn->candidateStart) < *(qn->candidateStart))
            {
                int parentStartPos = binarygreaterpos(*(parentQn->candidateStart),&(*nil)[0],nilStartPos+1,1);
                if(parentStartPos < nilStartPos)
                {
                    for(int i=parentStartPos; i<nilStartPos; i++)
                    {
//                    int p = (*nil)[i];
//                if(p==9848)
//                    p=9848;
                        candMap->erase((*nil)[i]);
                    }
                }


            }
            if(triePreOrder == PREFASC)
            {
                for(int i=nilStartPos; i<nil->size(); i++)
                {
                    map<int,Candidates_map>::iterator it = candMap->find((*nil)[i]);
                    it->second.queryDepth =  qn->queryDepth;
                    it->second.trieDepth = node->depth;
                    it->second.lastTranDepth =  tranDepth;
                }

            }
            else
            {
                //对PREFDESC而言，在查询深度为1时记录tranDepth和trie的depth即可
                for(int i=nilStartPos; i<nil->size(); i++)
                {
                    map<int,Candidates_map>::iterator it = candMap->find((*nil)[i]);
                    it->second.queryDepth =  qn->queryDepth;
                    //it->second.trieDepth = node->depth;
                    //it->second.lastTranDepth =  tranDepth;
                }

            }



        }

    }

}

//使用map进行查询处理，与process_map类似：过滤+验证
//not update, may not be correct
void Trie::process_map_query(Transaction *tran, SimiCache *simCache)
{
//
//    int start, end;
//    int k=0;  //存储当前查询元素在triePreOrder序中的位置
//    map<TrieNode *,QueryNode> nodeMap;
//    if(triePreOrder == PREFASC)
//    {
//        start = 0;
//        end = simCache->maxPrefixLen-1;
//    }
//    else
//    {
//        start = simCache->maxPrefixLen-1;
//        end = 0;
//    }
//
//    map<int,Candidates_map> allCandidates;
////    //vector<vector<int> *> allExcludes;
////
////    if(tran->id == 10135)
////    {
////        k++;
////    }
//    for(int i=start;;)
//    {
//        if(triePreOrder == PREFASC)
//        {
//            if(i > end)
//                break;
//        }
//        else
//        {
//            if( i < end)
//                break;
//        }
//        TrieNode * node = header[tran->t[i]];
//        while(node)
//        {
//            QueryNode qnode;
//
//            if(i == start)
//            {
//                qnode.queryDepth = 1;
//                //查询中第start个元素对应第1层查询节点
//                lpFilter_map_query(i,node,&qnode,NULL,&allCandidates,simCache);
//            }
//            else
//            {
//                int stride =0;
//                TrieNode * ancestornode = findNearestAncestor(node,tran,i,simCache, stride);
//                if(ancestornode)
//                {
//                    QueryNode parentNode = nodeMap[ancestornode];
//                    //过滤传播机制（子树过滤）:父节点被过滤，则所有子节点均被过滤
//                    if(parentNode.isFiltered == true)
//                    {
//                        qnode.isFiltered = true;
//                        //  qnode->queryDepth = parentNode->queryDepth +1;
//                    }
//                    else
//                    {
//                        qnode.queryDepth = parentNode.queryDepth +1;
//                        qnode.diff = parentNode.diff + stride;//diff仅对PREFDESC有效
//                        lpFilter_map_query(i,node,&qnode,&parentNode,&allCandidates,simCache);
//
//                    }
//                }
//                else
//                {
//                    //the first layer query node
//                    qnode.queryDepth = 1;
//                    lpFilter_map_query(i,node,&qnode,NULL,&allCandidates,simCache);
//                }
//
//            }
//            nodeMap[node] = qnode;
//            node = node->getNext();
//            nodesaccessed++;
//        }
//        //k++;
//        if(triePreOrder == PREFASC)
//        {
//            i++;
//        }
//        else
//        {
//            i--;
//        }
//    }
//
//
//    int count = allCandidates.size();
//    //验证候选集，其中统一过滤排除掉的集合
//    for(map<int,Candidates_map>::iterator it= allCandidates.begin(); it!=allCandidates.end(); it++)
//    {
//        int id = it->first;
////        if(id==5420)
////        {
////            int k =0;
////        }
//        //此处需计算索引的记录而非当前访问的记录的中等前缀
//        int candMidPreLen = Similarity::getMidPrefix(data->vec_trans[id]->length,simType,threshold);
//        //需要注意tranDepth从0或前缀减1位置开始，而trieDepth和queryDepth都从1开始
//        int lastTranDepth = it->second.lastTranDepth;
//        int overFounded = it->second.queryDepth;
//        int trieDepth = it->second.trieDepth;
//        Transaction *candTran = data->vec_trans[id];
//        int tranStart, candStart;
//
//        if(triePreOrder == PREFASC)
//        {
//            if(candTran->t[candMidPreLen-1] > tran->t[simCache->maxPrefixLen-1])
//            {
//                tranStart = simCache->maxPrefixLen;
//                candStart = trieDepth;
//            }
//            else
//            {
//                tranStart = lastTranDepth+1;
//                candStart = candMidPreLen;
//            }
//
//        }
//        else
//        {
//
//            if(candTran->t[candMidPreLen-1]>tran->t[simCache->maxPrefixLen-1])
//            {
//                tranStart = simCache->maxPrefixLen;
//                candStart = candMidPreLen - trieDepth +1;
//            }
//            else
//            {
//                tranStart = lastTranDepth+1;
//                candStart = candMidPreLen;
//            }
//
//
//        }
//
//        if(verify(tran,candTran,tranStart,candStart,overFounded,simCache->minOverlap[candTran->length]))
//        {
//            resultSize++;
//            result.push_back(tran->id);
//            result.push_back(candTran->id);
//            //cout<<tran->id<<" "<<candTran->id<<endl;
//        }
//
//
//    }

}

//获得候选集和排除集
//not update, may not be correct
void Trie::lpFilter_map_query(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn, map<int,Candidates_map> *candMap,SimiCache *simCache)
{

}

//过滤获得候选集和排除集
//1.计算节点的长度下界；
//2.若节点的最大长度小于下界，则过滤该节点；
//3.找到第一个满足下界的集合ID的位置；
//4.根据查询元素深度进行不同的处理，生成候选集并过滤
void Trie::lpFilter(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,vector<Candidates *> *allCandidates,SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    int rightMostID = (*nil)[nil->size()-1];
    int lenLBound;
    if(triePreOrder == PREFASC)
    {
        lenLBound = simCache->lpLBound[node->depth - qn->queryDepth];
    }
    else
    {
        lenLBound = simCache->lpLBound[qn->diff];
    }
//    int key = 11580;
//    if(-1!=binary(key,&(*nil)[0],nil->size()))
//    {
//        key=11580;
//    }
    //如果节点的nil中最右的节点长度小于lpFilter的条件，可安全过滤整个节点及所有孩子查询节点
    if(data->vec_trans[rightMostID]->length < lenLBound)
        qn->isFiltered = true;
    else
    {
        //此处调用getProbeLen方法是因为某些长度对应的记录可能为空，
        //startIDLBound表示大于等于lenLBound的且不为空的记录ID的起始位置。

        int startIDLBound = data->lenIdx[data->getLenNoLessThan(lenLBound)]->start;

        //nilStartPos表示中地一个大于等于startIDLBound的位置，也即是满足lpFilter的起始位置
        int nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

        qn->candidateStart = &(*nil)[nilStartPos];
        if(qn->queryDepth ==1) //对查询深度为1的节点，构造初始候选集
        {
            Candidates *candidates = new Candidates(nil->size()-nilStartPos);
            candidates->tranDepth = tranDepth;
            candidates->trieDepth = node->depth;

            memcpy(&(*candidates->cands)[0],&(*nil)[nilStartPos], sizeof(int)*(nil->size()-nilStartPos));
            allCandidates->push_back(candidates);
            //allExcludes->push_back(excludes);
            //每个查询节点指向存放其候选集的vector的位置
            qn->candidatesPos = allCandidates->size()-1;

        }
        else
        {
            //对查询深度不等于1的查询节点，获得该节点所过滤的集合，存储在excludes中
            //过滤的基本思想是：父查询节点候选集起点元素到子节点反向列表的映射 到本查询节点的候选集起点元素之间的所有元素为本节点过滤的元素
            qn->candidatesPos = parentQn->candidatesPos;

            //nilStartPos==0 means no unqualifying IDs to be removed.
            if(nilStartPos!= 0 && *(parentQn->candidateStart) < *(qn->candidateStart))
            {
                int parentStartPos = binarygreaterpos(*(parentQn->candidateStart),&(*nil)[0],nilStartPos+1,1);
                if(parentStartPos == nilStartPos) return;
//                if(-1!=binary(key,&(*nil)[0],nil->size()))
//                {
//                    key=11580;
//                }
                vector<int> *excludes = (*allCandidates)[qn->candidatesPos]->excludes;
                int excludeLen = nilStartPos-parentStartPos;
                int curSize = excludes->size();
                excludes->resize(curSize+ excludeLen);
                memcpy(&(*excludes)[curSize],&(*nil)[parentStartPos], sizeof(int)*(excludeLen));
            }

        }

    }

}


//生成候选集+验证
//1.根据前缀顺序确定每个集合在Trie中的起始位置和结束位置；
//2.遍历集合的前缀元素，找到每个集合对应的Trie节点；
//3.调用lpFilter函数进行候选集过滤；
//4.验证。并将匹配结果添加到结果集
void Trie::process(Transaction *tran, SimiCache *simCache)
{

    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;
    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    vector<Candidates *> allCandidates;
    //vector<vector<int> *> allExcludes;
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
        TrieNode * node = header[tran->t[i]];
        while(node)
        {
            //QueryNode *qnode = new QueryNode();
            QueryNode qnode;
            if(i == start)
            {
                qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                lpFilter(i,node,&qnode,NULL,&allCandidates,simCache);
            }
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor(node,tran,i,simCache,stride);
                if(ancestornode)
                {
                    QueryNode parentNode = nodeMap[ancestornode];
                    //过滤传播机制（子树过滤）:父节点被过滤，则所有子节点均被过滤
                    if(parentNode.isFiltered == true)
                    {
                        qnode.isFiltered = true;
                    }
                    else
                    {
                        qnode.queryDepth = parentNode.queryDepth +1;
                        qnode.diff = parentNode.diff + stride;//diff仅对PREFDESC有效
                        lpFilter(i,node,&qnode,&parentNode,&allCandidates,simCache);

                    }
                }
                else
                {
                    //the first layer query node
                    qnode.queryDepth = 1;
                    lpFilter(i,node,&qnode,NULL,&allCandidates,simCache);
                }

            }
            nodeMap[node] = qnode;
            node = node->getNext();
            nodesaccessed++;
        }
        //k++;
        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }

    }
    if(operType == JOIN)
        indexRecord(tran,simCache->midPrefixLen);


//验证候选集，其中统一过滤排除掉的集合
    for(int i=0; i<allCandidates.size(); i++)
    {
        vector<int> *candidates = allCandidates[i]->cands;
        vector<int> *excludes = allCandidates[i]->excludes;
        //需要注意tranDepth从0或前缀减1位置开始，而trieDepth和queryDepth都从1开始
        int tranPos = allCandidates[i]->tranDepth;
        int trieDepth = allCandidates[i]->trieDepth;
        int overFounded = allCandidates[i]->queryDepth;

        //注意到excludes中的ID 是未排序的
        if(excludes->size()>0)
            sort(excludes->begin(),excludes->end());
        int cpos = 0, epos =0;
        candidateSize = candidateSize + candidates->size() - excludes->size();
        while (cpos<candidates->size()&& epos < excludes->size())
        {
            if((*candidates)[cpos]<(*excludes)[epos])
            {
                Transaction *candTran = data->vec_trans[(*candidates)[cpos]];
                if(triePreOrder == PREFASC)
                {
                    if(verify(tran,candTran,tranPos+1,trieDepth,overFounded,simCache->minOverlap[candTran->length]))
                    {
                        resultSize++;
                        result.push_back(tran->id);
                        result.push_back(candTran->id);
                    }

                }
                else
                {
                    int canMidPrefLen = Similarity::getMidPrefix(candTran->length,simType,threshold);
                    if(verify_desc(tran,candTran,tranPos,canMidPrefLen - trieDepth,simCache->maxPrefixLen -1, canMidPrefLen-1,overFounded,simCache->minOverlap[candTran->length]))
                    {
                        resultSize++;
                        result.push_back(tran->id);
                        result.push_back(candTran->id);
                    }
                }
                cpos++;
            }
            else if((*candidates)[cpos]>(*excludes)[epos])
            {
                epos++;
            }
            else
            {
                cpos++;
                epos++;
            }
        }
        while (cpos<candidates->size())
        {
            Transaction *candTran = data->vec_trans[(*candidates)[cpos]];
            if(triePreOrder == PREFASC)
            {
                if(verify(tran,candTran,tranPos+1,trieDepth,overFounded,simCache->minOverlap[candTran->length]))
                {
                    resultSize++;
                    result.push_back(tran->id);
                    result.push_back(candTran->id);
                }

            }
            else
            {
                int canMidPrefLen = Similarity::getMidPrefix(candTran->length,simType,threshold);
                if(verify_desc(tran,candTran,tranPos,canMidPrefLen - trieDepth,simCache->maxPrefixLen -1, canMidPrefLen-1,overFounded,simCache->minOverlap[candTran->length]))
                {
                    resultSize++;
                    result.push_back(tran->id);
                    result.push_back(candTran->id);
                }
            }

            cpos++;
        }
    }
    for (int i =0; i<allCandidates.size(); i++)
    {
        delete allCandidates[i];
    }
}

//获得候选集和排除集
//该函数用于对查询集的候选集过滤
//1.计算节点的长度上届和下界；
//2.若上届<下界，直接过滤该节点（长位过滤也是该思想）；
//3.根据节点的最小和最大长度以及上下届，确定候选集的起始位置和结束位置
//4.根据查询深度进行不同的处理，生成候选集并进行过滤
void Trie::lpFilter_query(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,vector<Candidates *> *allCandidates,SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    int rightMostID = (*nil)[nil->size()-1];
    int leftMostID = (*nil)[0];

    //lpUBound is used to determine the maxPrefixLen for each set.
    int lpLBound, ldLBound=0, lpUBound;//,finalLBound
//    if(node->depth > simCache->maxsizePrefixLen)
//    {
//        qn->isFiltered =true;
//        return;
//    }

    lpLBound = simCache->lpLBound[node->depth - qn->queryDepth];
    lpUBound = simCache->lpUBound[tranDepth+1 - qn->queryDepth];

    if (lpUBound<lpLBound)
    {
        qn->isFiltered = true;
        return;
    }

    //不相交过滤
    //如果节点的nil中最右的节点长度小于下界或最左节点长度大于上界条件，可安全过滤整个节点及所有孩子查询节点
    if(data->vec_trans[rightMostID]->length < lpLBound ||
            data->vec_trans[leftMostID]->length >lpUBound)
    {
        qn->isFiltered = true;
        return;
    }
    //检测起始和终止位置
    int startIDLBound, endIDLBound, nilStartPos, nilEndPos;
    if (lpLBound <= data->vec_trans[leftMostID]->length && lpUBound >= data->vec_trans[rightMostID]->length )
    {
        nilStartPos =0;
        nilEndPos =nil->size()-1;
    }
    else if(lpLBound <= data->vec_trans[leftMostID]->length)
    {
        nilStartPos =0;
        endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
        nilEndPos =nilStartPos + binarysmallerpos(endIDLBound,&(*nil)[nilStartPos],nil->size()-nilStartPos,1);
    }
    else if(lpUBound >= data->vec_trans[rightMostID]->length)
    {
        startIDLBound = data->lenIdx[data->getLenNoLessThan(lpLBound)]->start;
        nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);
        nilEndPos =nil->size()-1;
    }

    else
    {
        startIDLBound = data->lenIdx[data->getLenNoLessThan(lpLBound)]->start;
        nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

        endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
        nilEndPos = nilStartPos + binarysmallerpos(endIDLBound,&(*nil)[nilStartPos],nil->size()-nilStartPos,1);

    }

    int candCount  = nilEndPos - nilStartPos + 1;
    qn->candidateStart = &(*nil)[nilStartPos];
    qn->candCount = candCount;
    if(qn->queryDepth ==1) //对查询深度为1的节点，构造初始候选集
    {
        Candidates *candidates = new Candidates(candCount);
        candidates->tranDepth = tranDepth;
        candidates->trieDepth = node->depth;

        memcpy(&(*candidates->cands)[0],&(*nil)[nilStartPos], sizeof(int)*(candCount));
        allCandidates->push_back(candidates);
        //allExcludes->push_back(excludes);
        //每个查询节点指向存放其候选集的vector的位置
        qn->candidatesPos = allCandidates->size()-1;

    }
    else //构造排除集
    {
        //对查询深度不等于1的查询节点，获得该节点所过滤的集合，存储在excludes中
        //过滤的基本思想是：父查询节点候选集起点元素到子节点反向列表的映射 到本查询节点的候选集起点元素之间的所有元素为本节点过滤的元素
        qn->candidatesPos = parentQn->candidatesPos;

        //nilStartPos==0 means no unqualifying IDs to be removed.
        //filter left half part
        if(nilStartPos!= 0 && *(parentQn->candidateStart) < *(qn->candidateStart))
        {
            int parentStartPos = binarygreaterpos(*(parentQn->candidateStart),&(*nil)[0],nilStartPos+1,1);
            if(parentStartPos == nilStartPos) return;

            vector<int> *excludes = (*allCandidates)[qn->candidatesPos]->excludes;
            int excludeLen = nilStartPos-parentStartPos;
            int curSize = excludes->size();
            excludes->resize(curSize+ excludeLen);
            memcpy(&(*excludes)[curSize],&(*nil)[parentStartPos], sizeof(int)*(excludeLen));
        }

        //filter right half part
        int *parentEnd = parentQn->candidateStart+parentQn->candCount-1;

        if(nilEndPos!= nil->size()-1 && *(parentEnd) > (*nil)[nilEndPos])
        {
            int parentEndPos = nilEndPos+binarysmallerpos(*(parentEnd),&(*nil)[nilEndPos],nil->size()-nilEndPos,1);
            if(parentEndPos == nilEndPos) return;
//
            vector<int> *excludes = (*allCandidates)[qn->candidatesPos]->excludes;
            int excludeLen = parentEndPos-nilEndPos;
            int curSize = excludes->size();
            excludes->resize(curSize+ excludeLen);
            memcpy(&(*excludes)[curSize],&(*nil)[nilEndPos], sizeof(int)*(excludeLen));
        }

    }

}


////获得候选集和排除集
//void Trie::lpFilter_query(int tranDepth,TrieNode * node,QueryNode *qn,QueryNode *parentQn,vector<Candidates *> *allCandidates,SimiCache *simCache)
//{
//    vector<int> *nil = node->index->arr;
//    int rightMostID = (*nil)[nil->size()-1];
//    int leftMostID = (*nil)[0];
//
//    //lpUBound is used to determine the maxPrefixLen for each set.
//    int lpLBound, ldLBound=0, lpUBound;//,finalLBound
////    if(node->depth > simCache->maxsizePrefixLen)
////    {
////        qn->isFiltered =true;
////        return;
////    }
//
//    lpLBound = simCache->lpLBound[node->depth - qn->queryDepth];
//    lpUBound = simCache->lpUBound[tranDepth+1 - qn->queryDepth];
//
//    if (lpUBound<lpLBound)
//    {
//        qn->isFiltered = true;
//        return;
//    }
//
//    //不相交过滤
//    //如果节点的nil中最右的节点长度小于下界或最左节点长度大于上界条件，可安全过滤整个节点及所有孩子查询节点
//    if(data->vec_trans[rightMostID]->length < lpLBound ||
//            data->vec_trans[leftMostID]->length >lpUBound)
//    {
//        qn->isFiltered = true;
//        return;
//    }
//    //检测起始和终止位置
//    int startIDLBound, endIDLBound, nilStartPos, nilEndPos;
//    if (lpLBound <= data->vec_trans[leftMostID]->length && lpUBound >= data->vec_trans[rightMostID]->length )
//    {
//        nilStartPos =0;
//        nilEndPos =nil->size()-1;
//    }
//    else if(lpLBound <= data->vec_trans[leftMostID]->length)
//    {
//        nilStartPos =0;
//        endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
//        nilEndPos =nilStartPos + binarysmallerpos(endIDLBound,&(*nil)[nilStartPos],nil->size()-nilStartPos,1);
//    }
//    else if(lpUBound >= data->vec_trans[rightMostID]->length)
//    {
//        startIDLBound = data->lenIdx[data->getLenNoLessThan(lpLBound)]->start;
//        nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);
//        nilEndPos =nil->size()-1;
//    }
//
//    else
//    {
//        startIDLBound = data->lenIdx[data->getLenNoLessThan(lpLBound)]->start;
//        nilStartPos = binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);
//
//        endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
//        nilEndPos = nilStartPos + binarysmallerpos(endIDLBound,&(*nil)[nilStartPos],nil->size()-nilStartPos,1);
//
//    }
//
//    int candCount  = nilEndPos - nilStartPos + 1;
//    qn->candidateStart = &(*nil)[nilStartPos];
//    qn->candCount = candCount;
//    if(qn->queryDepth ==1) //对查询深度为1的节点，构造初始候选集
//    {
//        Candidates *candidates = new Candidates(candCount);
//        candidates->tranDepth = tranDepth;
//        candidates->trieDepth = node->depth;
//
//        memcpy(&(*candidates->cands)[0],&(*nil)[nilStartPos], sizeof(int)*(candCount));
//        allCandidates->push_back(candidates);
//        //allExcludes->push_back(excludes);
//        //每个查询节点指向存放其候选集的vector的位置
//        qn->candidatesPos = allCandidates->size()-1;
//
//    }
//    else //构造排除集
//    {
//        //对查询深度不等于1的查询节点，获得该节点所过滤的集合，存储在excludes中
//        //过滤的基本思想是：父查询节点候选集起点元素到子节点反向列表的映射 到本查询节点的候选集起点元素之间的所有元素为本节点过滤的元素
//        qn->candidatesPos = parentQn->candidatesPos;
//
//        //nilStartPos==0 means no unqualifying IDs to be removed.
//        //filter left half part
//        if(nilStartPos!= 0 && *(parentQn->candidateStart) < *(qn->candidateStart))
//        {
//            int parentStartPos = binarygreaterpos(*(parentQn->candidateStart),&(*nil)[0],nilStartPos+1,1);
//            if(parentStartPos == nilStartPos) return;
//
//            vector<int> *excludes = (*allCandidates)[qn->candidatesPos]->excludes;
//            int excludeLen = nilStartPos-parentStartPos;
//            int curSize = excludes->size();
//            excludes->resize(curSize+ excludeLen);
//            memcpy(&(*excludes)[curSize],&(*nil)[parentStartPos], sizeof(int)*(excludeLen));
//        }
//
//        //filter right half part
//        int *parentEnd = parentQn->candidateStart+parentQn->candCount-1;
//
//        if(nilEndPos!= nil->size()-1 && *(parentEnd) > (*nil)[nilEndPos])
//        {
//            int parentEndPos = nilEndPos+binarysmallerpos(*(parentEnd),&(*nil)[nilEndPos],nil->size()-nilEndPos,1);
//            if(parentEndPos == nilEndPos) return;
////
//            vector<int> *excludes = (*allCandidates)[qn->candidatesPos]->excludes;
//            int excludeLen = parentEndPos-nilEndPos;
//            int curSize = excludes->size();
//            excludes->resize(curSize+ excludeLen);
//            memcpy(&(*excludes)[curSize],&(*nil)[nilEndPos], sizeof(int)*(excludeLen));
//        }
//
//    }
//
//}


//查询集处理函数：生成候选集并验证
//1.确定集合的前缀，即前缀的起始位置和结束位置
//2.遍历集合的前缀元素，查找对应的Trie树节点
//3.调用lpFilter_query函数进行候选集过滤
//4.验证并将结果集添加到结果集
void Trie::process_query(Transaction *tran, SimiCache *simCache)
{

    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;
    if(triePreOrder == PREFASC)//前缀升序
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else//前缀降序
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }


    vector<Candidates *> allCandidates;
    //vector<vector<int> *> allExcludes;
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {

            TrieNode * node = *it;
            QueryNode qnode;
            //节点过滤
            if(node->depth > simCache->maxsizePrefixLen)  //节点深度过滤
            {
                //node = node->getNext();
                nodesaccessed++;
                break;
            }

            if(i == start|| node->depth == 1)
            {
                qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                lpFilter_query(0,node,&qnode,NULL,&allCandidates,simCache);
            }
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(ancestornode)
                {
                    QueryNode parentNode = nodeMap[ancestornode];
                    //过滤传播机制（子树过滤）:父节点被过滤，则所有子节点均被过滤
                    if(parentNode.isFiltered == true)
                    {
                        qnode.isFiltered = true;
                    }
                    else
                    {
                        qnode.queryDepth = parentNode.queryDepth +1;
                        qnode.diff = parentNode.diff + stride;//diff仅对PREFDESC有效
                        lpFilter_query(abs(i-start),node,&qnode,&parentNode,&allCandidates,simCache);

                    }
                }
                else
                {
                    //the first layer query node
                    qnode.queryDepth = 1;
                    lpFilter_query(abs(i-start),node,&qnode,NULL,&allCandidates,simCache);
                }

            }
            nodeMap[node] = qnode;
            //node = node->getNext();
            nodesaccessed++;
        }
        //k++;
        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }

    }

    //验证候选集，其中统一过滤排除掉的集合，生成结果集对，每次生成一对
    for(int i=0; i<allCandidates.size(); i++)
    {
        vector<int> *candidates = allCandidates[i]->cands;
        vector<int> *excludes = allCandidates[i]->excludes;
        //需要注意tranDepth从0或前缀减1位置开始，而trieDepth和queryDepth都从1开始
        int tranPos = allCandidates[i]->tranDepth;
        int trieDepth = allCandidates[i]->trieDepth;
        int overFounded = allCandidates[i]->queryDepth;

//        int key = 11580;
//        if(-1!=binary(key,&(*candidates)[0],candidates->size()))
//        {
//            key=11580;
//        }
        //注意到excludes中的ID 是未排序的
        sort(excludes->begin(),excludes->end());
        int cpos = 0, epos =0;
        candidateSize = candidateSize + candidates->size() - excludes->size();
        while (cpos<candidates->size()&& epos < excludes->size())
        {
//            int id = (*candidates)[cpos];
//            if(id==11580)
//            {
//                int p=1;
//                p++;
//            }
            if((*candidates)[cpos]<(*excludes)[epos])
            {
                Transaction *candTran = data->vec_trans[(*candidates)[cpos]];
                //if(triePreOrder == DESC)

                if(verify(tran,candTran,tranPos+1,trieDepth,overFounded,simCache->minOverlap[candTran->length]))
                {
                  //  cout<<tran->id<<","<<candTran->id<<endl;
                    resultSize++;
                    result.push_back(tran->id);
                    result.push_back(candTran->id);
                }
                cpos++;
            }
            else if((*candidates)[cpos]>(*excludes)[epos])
            {
                epos++;
            }
            else
            {
                cpos++;
                epos++;
            }
        }
        while (cpos<candidates->size())
        {
            Transaction *candTran = data->vec_trans[(*candidates)[cpos]];
            if(verify(tran,candTran,tranPos+1,trieDepth,overFounded,simCache->minOverlap[candTran->length]))
            {
                //cout<<tran->id<<","<<candTran->id<<endl;
                resultSize++;
                result.push_back(tran->id);
                result.push_back(candTran->id);
            }
            cpos++;
        }
    }
    for (int i =0; i<allCandidates.size(); i++)
    {
        delete allCandidates[i];
    }
}



//找到1-匹配节点FMNode
//1.计算节点的长度下界和上届，快速过滤完全不可能匹配的事务,精准过滤
//2.验证
void Trie::verify_query_l1_postlp(Transaction *tran,int tranDepth,TrieNode * node,SimiCache *simCache, int start)
{
    vector<int> *nil = node->index->arr;
    invlistSetTotal += nil->size();
    int rightMostID = (*nil)[nil->size()-1];
    int leftMostID = (*nil)[0];

    int lpLBound, lpUBound;//,finalLBound

    //后面2行的1本应为qn->depth,因只考虑查询深度为1的节点，现改为1;<即查询节点首次出现在Trie中的节点位置>

    //在PREFDESC时，因为trie中节点深度并不代表其在对应记录中的深度，所以长位过滤不能和PREDESC共存。
    //因此长位过滤=长度升序/降序+前缀升序，前缀降序未完善
    //所以，此处长位过滤应退化为长度过滤
    //后续通过在节点上做标记（标记本节点在所对应的记录中最小位置）并引入“位置差”来缓解这一问题。
    if(triePreOrder==PREFASC)
    {
        //直接利用深度过滤：长度为i的查询节点在树不同深度时，满足相似性阈值的上届和下界
        lpLBound = simCache->lpLBound[node->depth - 1];//前缀深度计算下界
        lpUBound = simCache->lpUBound[tranDepth];//用集合深度计算上届

    }
    else//未完善
    {
        lpLBound = simCache->minSize;
        lpUBound = simCache->maxSize;
    }
//上届<下界，比较结束
    if (lpUBound<lpLBound) return;

    //不相交过滤
    //如果节点的nil中最右的节点长度小于下界或最左节点长度大于上界条件，可安全过滤整个节点及所有孩子查询节点
    if(data->vec_trans[rightMostID]->length < lpLBound ||
            data->vec_trans[leftMostID]->length >lpUBound) return;

    //检测起始和终止位置
    int startIDLBound, nilStartPos, nilCurPos;


    startIDLBound = data->lenIdx[data->getLenNoLessThan(lpLBound)]->start;
    //endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
    nilCurPos=nilStartPos=startIDLBound<=leftMostID?0:binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

    while(nilCurPos<=nil->size()-1 && data->vec_trans[(*nil)[nilCurPos]]->length <= lpUBound)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];
        //测试:输出候选集
        //cout << " candTran:" << endl;
        //cout << "candTran_ID:" << candTran->id << endl;
        //cout << "candTran_length:" << candTran->length << endl;
        //cout << "comment:";
        //for (int i = 0; i < candTran->length; i++) {
        //    cout << candTran->t[i] << " ";
        //}
    //cout << endl;
    //测试结束
    int candStart = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);
    int candPos = abs(candStart - node->depth + 1);

    //if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))

//注：该if语句和下列if语句功效一样
    totalCandidatesVerified++;  // 统计传入验证的候选集数目
    if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
    {
        //测试：输出匹配的字典对<查询集ID，满足条件的候选集ID>
        //cout<<tran->id<<","<<candTran->id<<endl;
        resultSize++;
        totalCandidatesPassed++;  // 统计通过验证的候选集数目
        //result.push_back(tran->id);
        //result.push_back(candTran->id);
    }

// if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
// {
//          cout<<tran->id<<","<<candTran->id<<endl;
//          resultSize++;
//             //result.push_back:可将结果集的内容写入resfile文件中
//              result.push_back(tran->id);
//             result.push_back(candTran->id);
//}

    nilCurPos++;
    }
    candidateSize += nilCurPos - nilStartPos+1;
}





//获得候选集和排除集
//1.验证，根据给定的查询集tran和树节点node,从节点索引里筛选出符合长度范围的候选集candTran
//2.通过精确验证verify_ASC_DESC判断集合是否满足阈值
void Trie::verify_query_l1(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache)
{
    //获取当前Trie节点索引中存储的集合ID列表
    vector<int> *nil = node->index->arr;
    //长度过滤：检测起始和终止位置，确定候选集的长度起始范围
    int startIDLBound, nilStartPos=0, nilCurPos=0;

    startIDLBound = data->lenIdx[data->getLenNoLessThan(simCache->minSize)]->start;
    //endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
    nilCurPos=nilStartPos=node->lowerLen>=simCache->minSize?0:binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);
    //遍历nil列表中符合长度范围的候选集，逐一验证与查询集的相似度
    while(nilCurPos<=nil->size()-1 && data->vec_trans[(*nil)[nilCurPos]]->length <= simCache->maxSize )
    {
        //根据节点索引取出当前候选集
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];
        //计算候选集用于验证的起始位置
        int start = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);

        int candPos = abs(start - node->depth + 1);

        //if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
        //调用verify_ASC_DESC函数验证查询集与候选集是否满足重叠要求，满足则统计
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            //验证通过：输出查询集和候选集的ID，记录匹配结果
            //cout<<tran->id<<","<<candTran->id<<endl;
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }
    //遍历当前结束位置和起始位置的差值，计算参与验证的候选集数量并累加
        nilCurPos++;//统计有效结果数量
    }
    candidateSize += nilCurPos - nilStartPos+1;
}


//获得候选集和排除集
void Trie::verify_query_l1_nolp(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    //检测起始和终止位置
    int startIDLBound, nilStartPos=0, nilCurPos=0;


    startIDLBound = data->lenIdx[data->getLenNoLessThan(simCache->minSize)]->start;
    //endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
    nilCurPos=nilStartPos=node->lowerLen>=simCache->minSize?0:binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

    while(nilCurPos<=nil->size()-1 && data->vec_trans[(*nil)[nilCurPos]]->length <= simCache->maxSize)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];

        int start = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);

        int candPos = abs(start - node->depth + 1);

        //if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            //输出返回结果ID
           // cout<<tran->id<<","<<candTran->id<<endl;
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }


//        //此处必须节点深处过滤，否则length会超标，导致查出来的结果不正确
//        if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
//        {
//            //cout<<tran->id<<","<<candTran->id<<endl;
//            resultSize++;
//        }

        nilCurPos++;
    }
    candidateSize += nilCurPos - nilStartPos+1;
}

//获得候选集和排除集
void Trie::verify_query_l1_prelp(Transaction *tran,int tranDepth,TrieNode * node,int minLen, int maxLen, SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    //检测起始和终止位置
    int startIDLBound,nilStartPos=0, nilCurPos=0;

    startIDLBound = data->lenIdx[data->getLenNoLessThan(minLen)]->start;
    //endIDLBound= data->lenIdx[data->getLenNoLessThan(lpUBound+1)]->start-1;
    nilCurPos=nilStartPos=minLen==node->lowerLen?0:binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

    while(nilCurPos<=nil->size()-1 && data->vec_trans[(*nil)[nilCurPos]]->length <=maxLen)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];
        int start = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);

        int candPos = abs(start - node->depth + 1);

        //if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            //输出返回结果ID
           // cout<<tran->id<<","<<candTran->id<<endl;
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }

//
//        if(verify(tran,candTran,tranDepth+1,node->depth,1,simCache->minOverlap[candTran->length]))
//        {
//            //cout<<tran->id<<","<<candTran->id<<endl;
//            resultSize++;
//        }

        nilCurPos++;
    }
    candidateSize += nilCurPos - nilStartPos+1;
}

//处理查询集合域：过滤+验证
void Trie::process_query_l1(Transaction *tran, SimiCache *simCache)
{

    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;
    if(triePreOrder == PREFASC)//前缀升序
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else//前缀降序
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    for(int i=start;;)//遍历事务前缀
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
        //TrieNode * node = header[tran->t[i]];
        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {

            TrieNode * node = *it;
            //QueryNode *qnode = new QueryNode();
//            //QueryNode qnode;
            if(node->depth > simCache->maxsizePrefixLen)  //节点深度过滤，此处假设节点深度无序
            {
                //node = node->getNext();
                nodesaccessed++;
                continue;
            }

            if(i == start || node->depth == 1)
            {
                //qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                //lpFilter_query(0,node,&qnode,NULL,&allCandidates,simCache);
                verify_query_l1(tran,i,node,simCache);
                //verify_query_l1(tran,i,node,minLen,maxLen,simCache);
            }
            else
            {
                int stride =0;
                //TrieNode * ancestornode = findNearestAncestor_l1(node,tran,i,simCache,stride);

                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    //the first layer query node
                    //qnode.queryDepth = 1;
                    //lpFilter_query(abs(i-start),node,&qnode,NULL,&allCandidates,simCache);
                    //lpFilterandVerify_query_l1(tran,abs(i-start),node,simCache);

                    verify_query_l1(tran,i,node,simCache);
                }

            }
            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }

    }

}

void Trie::process_query_l1_nolp(Transaction *tran, SimiCache *simCache)
{

    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;
    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }


    //vector<vector<int> *> allExcludes;
    //for(int i=start;i<=simCache->maxPrefixLen-1;i++)
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
        //TrieNode * node = header[tran->t[i]];
        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {

            TrieNode * node = *it;
            //QueryNode *qnode = new QueryNode();
//            //QueryNode qnode;
            if(node->depth > simCache->maxsizePrefixLen)  //节点深度过滤
            {
                //node = node->getNext();
                nodesaccessed++;
                break;
            }

//            int diff = abs(node->depth - min(i+1,node->depth));
//            int diff1 = i-min(i,node->depth-1);
//            int lpLBound = simCache->lpLBound[diff];
//            int lpUBound = simCache->lpUBound[diff1];
//
//            //node->depth - qn->queryDepth
//            //tranDepth+1 - qn->queryDepth
//
//            if (lpUBound<lpLBound)//长位过滤，此处可证明，满足长位过滤其深度必然小于maxsizePref
//            {
//                nodesaccessed++;
//                break;
//            }
//            else if(lpLBound>node->upperLen || lpUBound < node->lowerLen)  //不相交过滤
//            {
//                nodesaccessed++;
//                continue;
//            }
//
//            int maxLen, minLen;
//            minLen = max(lpLBound, node->lowerLen);
//            maxLen = min(lpUBound,node->upperLen);

            if(i == start || node->depth == 1)
            {
                //qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                //lpFilter_query(0,node,&qnode,NULL,&allCandidates,simCache);
                verify_query_l1_nolp(tran,i,node,simCache);
                //verify_query_l1(tran,i,node,minLen,maxLen,simCache);
            }
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    //the first layer query node
                    //qnode.queryDepth = 1;
                    //lpFilter_query(abs(i-start),node,&qnode,NULL,&allCandidates,simCache);
                    //lpFilterandVerify_query_l1(tran,abs(i-start),node,simCache);

                    verify_query_l1_nolp(tran,i,node,simCache);
                }

            }
            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }

    }

}

//1.节点深度过滤：满足条件集合S的最大深度/前缀长度；2.长度界限过滤：找查询节点->筛选出1-匹配节点->对1-匹配节点FMNODE筛选出满足长度上下届的的集合
void Trie::process_query_l1_prelp(Transaction *tran, SimiCache *simCache)
{
    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    map<TrieNode *,QueryNode> nodeMap;
    //前缀升序
    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    //前缀降序
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    //vector<vector<int> *> allExcludes;
    //for(int i=start;i<=simCache->maxPrefixLen-1;i++)
    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
        //TrieNode * node = header[tran->t[i]];
        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {

            TrieNode * node = *it;
            //QueryNode *qnode = new QueryNode();
//            //QueryNode qnode;
            if(node->depth > simCache->maxsizePrefixLen)  //节点深度过滤
            {
                //node = node->getNext();
                nodesaccessed++;
                break;
            }

            int diff = abs(node->depth - min(i+1,node->depth));
            int diff1 = i-min(i,node->depth-1);
            int lpLBound = simCache->lpLBound[diff];
            int lpUBound = simCache->lpUBound[diff1];


            vector<int> *nil = node->index->arr;
            int nilLB = data->vec_trans[(*nil)[0]]->length;
            int nilUB = data->vec_trans[(*nil)[nil->size()-1]]->length;


            if (lpUBound<lpLBound)//长位过滤，此处可证明，满足长位过滤其深度必然小于maxsizePref
            {
                nodesaccessed++;
                break;
            }
            else if(lpLBound> nilUB || lpUBound < nilLB)  //不相交过滤
            {
                nodesaccessed++;
                continue;
            }

            int maxLen, minLen;
            minLen = max(lpLBound, nilLB);
            maxLen = min(lpUBound,nilUB);
            if(i == start || node->depth == 1)
            {
                //qnode.queryDepth = 1;//查询中第start个元素对应第1层查询节点
                //lpFilter_query(0,node,&qnode,NULL,&allCandidates,simCache);
                //verify_query_l1(tran,i,node,simCache);
                verify_query_l1_prelp(tran,i,node,minLen,maxLen,simCache);
            }
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    //the first layer query node
                    //qnode.queryDepth = 1;
                    //lpFilter_query(abs(i-start),node,&qnode,NULL,&allCandidates,simCache);
                    //lpFilterandVerify_query_l1(tran,abs(i-start),node,simCache);
                    verify_query_l1_prelp(tran,i,node,minLen,maxLen,simCache);
                }

            }
            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }

    }

}

void Trie::process_query_l1_postlp(Transaction *tran, SimiCache *simCache)
{


        // 前置安全检查
    if(!tran) {
        cout << "error：process_query_l1_postlp - the pointer is null." << endl;
        return;
    }

    if(!simCache) {
        cout << "error：process_query_l1_postlp - simCache is null pointer" << endl;
        return;
    }

    if(tran->length <= 0) {
        cout << "error：process_query_l1_postlp - set length is 0 or <0，set ID: " << tran->id << endl;
        return;
    }

    // 检查所有元素是否在有效范围内
    // for(int i = 0; i < tran->length; i++) {
   //     if(tran->t[i] < 0 || tran->t[i] >= sLNodes.size()) {
   //         cout << "error：element " << tran->t[i] << " more than sLNodes range [0, " << sLNodes.size()-1 << "]" << endl;
   //         cout << "set ID: " << tran->id << ",position: " << i << endl;
   //         return;
   //     }
   // }

    int start, end;
    int k=0;  //存储当前查询元素在triePreOrder序中的位置
    //查询节点和候选集节点:最大前缀即最大深度
    map<TrieNode *,QueryNode> nodeMap;

    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    //vector<vector<int> *> allExcludes;
    //找匹配节点
    for(int i=start;;)
    {

        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }
                // 添加额外的安全检查
        if(i < 0 || i >= tran->length) {
            cout << "error：index " << i << " more than set length " << tran->length << endl;
            break;
        }

        //int element = tran->t[i];
        //if(element < 0 || element >= sLNodes.size()) {
        //    cout << "error：element " << element << " more than sLNodes range" << endl;
        //    break;
        //}

        //TrieNode * node = header[tran->t[i]];
        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {

            TrieNode * node = *it;
            //QueryNode *qnode = new QueryNode();
//            //QueryNode qnode;
//节点深度过滤
            if(node->depth > simCache->maxsizePrefixLen)
            {
                //node = node->getNext();
                nodesaccessed++;
                //cout<<"test"<<endl;
                break;
            }
//深度为1的匹配节点FMNode
            if(i == start || node->depth == 1)
            {
                //qnode.queryDepth = 1;
                //查询中第start个元素对应第1层查询节点
                //lpFilter_query(0,node,&qnode,NULL,&allCandidates,simCache);
                //cout<<"before"<<endl;
                cnt_call_verify_l1_postlp++;
                verify_query_l1_postlp(tran,i,node,simCache,start);
                //cout<<"after"<<endl;
                //verify_query_l1(tran,i,node,minLen,maxLen,simCache);
            }
//其它位置，计算位置差:深度不为1的FMNode
            else
            {
                int stride =0;
               // cout<<"before1"<<endl;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
               // cout<<"after1"<<endl;
                if(!ancestornode)
                {
                    //the first layer query node
                    //qnode.queryDepth = 1;
                    //lpFilter_query(abs(i-start),node,&qnode,NULL,&allCandidates,simCache);
                    //lpFilterandVerify_query_l1(tran,abs(i-start),node,simCache);

                    cnt_call_verify_l1_postlp++;
                    verify_query_l1_postlp(tran,i,node,simCache,start);
                    //verify_query_l1(tran,i,node,minLen,maxLen,simCache);
                }

            }

            nodesaccessed++;
        }
        //cout<<"nodesaccessed:"<<nodesaccessed<<endl;

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }
        //cout<<i<<endl;
    }

}

//tranLPos和candLPos在最左匹配点的左边一个位置， tranRPos和candRPos在最右匹配点的右侧一个位置
//如果仅考虑查询深度为1的节点时，tranLPos = 匹配点位置减1, tranRPos= 匹配点位置加1

bool Trie::verify_ASC_DESC(Transaction *tran, Transaction *cand, int tranLPos,int candLPos, int tranRPos,int candRPos,int foundoverlap,int overlapthres)
{
    unsigned int maxr1;
    unsigned int maxr2;
    unsigned int steps = 0;
    if(triePreOrder == PREFDESC)
    {
        maxr1 = tran->length - (tranRPos-tranLPos-1) + foundoverlap;
        maxr2 = cand->length - (candRPos-candLPos-1) + foundoverlap;
        while(maxr1 >= overlapthres && maxr2 >= overlapthres && foundoverlap < overlapthres && tranLPos>=0 && candLPos >=0)
        {
            steps++;
            if(tran->t[tranLPos] == cand->t[candLPos])
            {
                --tranLPos;
                --candLPos;
                ++foundoverlap;
            }
            else if (tran->t[tranLPos] > cand->t[candLPos])
            {
                --tranLPos;
                --maxr1;
            }
            else
            {
                --candLPos;
                --maxr2;
            }
        }
        if(tranLPos<0 && candLPos >=0)
        {
            maxr2 -= candLPos+1;
        }
        else if(tranLPos>=0 && candLPos <0)
        {
            maxr1 -= tranLPos+1;
        }
    }
    else
    {
        maxr1 = tran->length - tranRPos + foundoverlap;
        maxr2 = cand->length - candRPos + foundoverlap;
    }

    while(maxr1 >= overlapthres && maxr2 >= overlapthres && foundoverlap < overlapthres)
    {

        steps++;
        if(tran->t[tranRPos] == cand->t[candRPos])
        {
            ++tranRPos;
            ++candRPos;
            ++foundoverlap;
        }
        else if (tran->t[tranRPos] < cand->t[candRPos])
        {
            ++tranRPos;
            --maxr1;
        }
        else
        {
            ++candRPos;
            --maxr2;
        }
    }

    return foundoverlap >= overlapthres;
}



bool Trie::verify(Transaction *tran, Transaction *cand, int tranPos,int candPos,int foundoverlap,int overlapthres)
{
    unsigned int maxr1 = tran->length - tranPos + foundoverlap;
    unsigned int maxr2 = cand->length- candPos + foundoverlap;

    unsigned int steps = 0;

    while(maxr1 >= overlapthres && maxr2 >= overlapthres && foundoverlap < overlapthres)
    {
        steps++;
        if(tran->t[tranPos] == cand->t[candPos])
        {
            ++tranPos;
            ++candPos;
            ++foundoverlap;
        }
        else if (tran->t[tranPos] < cand->t[candPos])
        {
            ++tranPos;
            --maxr1;
        }
        else
        {
            ++candPos;
            --maxr2;
        }
    }


    return foundoverlap >= overlapthres;
}


//2 stage verify
//candMidPos is midPrefixLen-1 of cand, tranMaxpos is maxPrefixLen-1 of tran
//candPos is trieDepth-1,  tranPos = the first matched position in tran
bool Trie::verify_desc(Transaction *tran, Transaction *cand, int tranPos,int candPos,int tranMaxPos,int candMidPos,int foundoverlap,int overlapthres)
{
    int maxr1;
    int maxr2;

    if(cand->t[candMidPos] < tran->t[tranMaxPos])
    {
        maxr1 = tran->length - 1 + foundoverlap;
        maxr2 = cand->length -candMidPos + candPos -1 + foundoverlap;
    }
    else
    {
        maxr1 = tran->length - tranMaxPos + tranPos - 1 + foundoverlap;
        maxr2 = cand->length - 1 + foundoverlap;
    }

    unsigned int steps = 0;
    int tranPos2=0,candPos2=0;

    if( tranPos ==0 || candPos == 0 )
    {
        if(cand->t[candMidPos] < tran->t[tranMaxPos])
        {
            tranPos2 = tranPos +1;
            candPos2 = candMidPos +1;
        }
        else
        {
            tranPos2 = tranMaxPos +1;
            candPos2 = candPos +1;
        }
        maxr1 -= tranPos;
        maxr2 -= candPos;
    }
    else
    {
        while(maxr1 >= overlapthres && maxr2 >= overlapthres && foundoverlap < overlapthres)
        {
            steps++;
            if(candPos2 == candPos -1 && cand->t[candPos2] <= tran->t[tranPos2]
                    || tranPos2 == tranPos -1 && tran->t[tranPos2] <= cand->t[candPos2])
            {
                if(candPos2 == candPos -1 && cand->t[candPos2] == tran->t[tranPos2]
                        || tranPos2 == tranPos -1 && tran->t[tranPos2] == cand->t[candPos2])
                    ++foundoverlap;
                else
                {
                    maxr1 -= tranPos - tranPos2;
                    maxr2 -= candPos-candPos2;
                }

                if(cand->t[candMidPos] < tran->t[tranMaxPos])
                {
                    tranPos2 = tranPos +1;
                    candPos2 = candMidPos +1;
                }
                else
                {
                    tranPos2 = tranMaxPos +1;
                    candPos2 = candPos +1;
                }

                break;
            }
            if(tran->t[tranPos2] == cand->t[candPos2])
            {
                ++tranPos2;
                ++candPos2;
                ++foundoverlap;
            }
            else if (tran->t[tranPos2] < cand->t[candPos2])
            {
                ++tranPos2;
                --maxr1;
            }
            else
            {
                ++candPos2;
                --maxr2;
            }
        }

    }

    while(maxr1 >= overlapthres && maxr2 >= overlapthres && foundoverlap < overlapthres)
    {
        steps++;
        if(tran->t[tranPos2] == cand->t[candPos2])
        {
            ++tranPos2;
            ++candPos2;
            ++foundoverlap;
        }
        else if (tran->t[tranPos2] < cand->t[candPos2])
        {
            ++tranPos2;
            --maxr1;
        }
        else
        {
            ++candPos2;
            --maxr2;
        }
    }

    return foundoverlap >= overlapthres;
}


//TrieNode* Trie::findNearestAncestor(TrieNode * node,Transaction *st,int priorlen,int *pathLen)
TrieNode* Trie::findNearestAncestor(TrieNode * node,Transaction *st,int priorlen,SimiCache *simCache,int &stride)
{
    while (node->getParent())
    {

        //*pathLen ++;
        if(isNodeInQuery(node->getParent()->getId(),st,priorlen,simCache))
            return node->getParent();
        else
        {
            stride++;
            node = node->getParent();
        }
    }
    return NULL;
}


TrieNode* Trie::findNearestAncestor_l1(TrieNode * node,Transaction *st,int priorlen,SimiCache *simCache,int &stride)
{
    TrieNode *parentNode = node->parent;


    while (parentNode!=NULL && parentNode->nodeID >= st->t[0])
    {

        //*pathLen ++;
        if(isNodeInQuery_l1(parentNode->nodeID,st,priorlen,simCache))
        {
         return parentNode;
        }
        else
        {
            stride++;
            parentNode = parentNode->parent;
        }
    }
    return NULL;
}

//之前的算法存在以下不足：如果某节点未在查询中出现（从tranpos-1的位置向前查询），我们需要继续探测其父节点是否在查询中出现（同样从tranpos-1的位置向前查询）。
//如果从同一位置探测，造成不必要的节点访问，本函数采用类似列表归并的思路，可有效避免这一不足。
//此外，本函数支持对前缀部分创建频率降序trie的搜索

TrieNode* Trie::findNearestAncestor_l1_ADESC(TrieNode * node,Transaction *st,int tranPos,SimiCache *simCache,int &stride)
{
    TrieNode *parentNode = node->parent;
    int start;
    int curPos;

    if(triePreOrder == PREFASC)
    {

        curPos = tranPos-1;
        start = 0;
        while (parentNode!=NULL && parentNode->nodeID >= st->t[start])
        {
            ancestorNodesAccessed++;
            while(curPos>=0 && parentNode->nodeID < st->t[curPos])
            {
                curPos--;
            }
            if(parentNode->nodeID == st->t[curPos]) return parentNode;
            else if(curPos<0) return NULL;
            parentNode = parentNode->parent;
        }
        return NULL;
    }
    else
    {
        curPos = tranPos+1;
        start = simCache->maxPrefixLen -1;
        while (parentNode!=NULL && parentNode->nodeID <= st->t[start])
        {
            ancestorNodesAccessed++;
            while(curPos<=start && parentNode->nodeID > st->t[curPos])
            {
                curPos++;
            }
            if(parentNode->nodeID == st->t[curPos]) return parentNode;
            else if(curPos>start) return NULL;
            parentNode = parentNode->parent;
        }
        return NULL;

    }

}

TrieNode* Trie::isIDinAncestor(TrieNode * node,int id)
{
    while (node->getParent())
    {
        if(node->getParent()->getId()==id)
            return node->getParent();
        else
            node = node->getParent();
    }
    return NULL;
}

//void Trie::traverseFromNode(TrieNode * node,Query *query,int depth)
//{
//	int i;
//	if(depth>=query->T) return;
//	if(node->children->count <=0) return;
//	for(i =0;i<node->children->count;i++)
//	{
//
//		if( isNodeInQuery(((TrieNode *)node->children[i])->nodeID,query->sortedQuery))
//		{
//			depth ++;
//
//		}
//		else
//		{
//
//		}
//	}
//
//}
//
bool Trie::isNodeInQuery(int nodeid,Transaction *sortedt,int priorlen,SimiCache *simCache)
{
    //return binary_search(sortedt->t[0],sortedt->t[sortedt->length -1],nodeid);
    int res;
    if(triePreOrder == PREFASC)
    {
        res = binary(nodeid,sortedt->t,priorlen);
    }
    else
    {
        res = binary(nodeid,sortedt->t+priorlen+1,simCache->maxPrefixLen-1 - priorlen);
    }

    if(res==-1) return false;
    else return true;
}

bool Trie::isNodeInQuery_l1(int nodeid,Transaction *sortedt,int priorlen,SimiCache *simCache)
{
    //return binary_search(sortedt->t[0],sortedt->t[sortedt->length -1],nodeid);
    int i=priorlen-1;

    while(nodeid < sortedt->t[i] && i>=0)
    {
       i--;
    }
    if(nodeid == sortedt->t[i]) return true;
    else return false;
//
//    if(triePreOrder == PREFASC)
//    {
//        res = binary(nodeid,sortedt->t,priorlen);
//    }
//    else
//    {
//        res = binary(nodeid,sortedt->t+priorlen+1,simCache->maxPrefixLen-1 - priorlen);
//    }
//
//    if(res==-1) return false;
//    else return true;
}

void Trie::addToResult(vector<int> *res, vector<int> *ia)
{
    for(int j=0; j<ia->size(); j++)
    {
        res->push_back(ia->at(j));
    }
}

//DEPTH过滤：仅深度过滤 + 标准Jaccard验证
//深度过滤生成的候选集，直接送入Jaccard相似性验证
//不进行长度过滤和位置过滤
void Trie::process_query_l1_depthlp(Transaction *tran, SimiCache *simCache)
{
    //前置安全检查
    if(!tran) {
        cout << "error：process_query_l1_depthlp - the pointer is null." << endl;
        return;
    }

    if(!simCache) {
        cout << "error：process_query_l1_depthlp - simCache is null pointer" << endl;
        return;
    }

    if(tran->length <= 0) {
        cout << "error：process_query_l1_depthlp - set length is 0 or <0，set ID: " << tran->id << endl;
        return;
    }

    int start, end;
    int k=0;
    map<TrieNode *,QueryNode> nodeMap;

    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }

        if(i < 0 || i >= tran->length) {
            cout << "error：index " << i << " more than set length " << tran->length << endl;
            break;
        }

        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {
            TrieNode * node = *it;

            //深度过滤
            if(node->depth > simCache->maxsizePrefixLen)
            {
                nodesaccessed++;
                break;
            }

            //深度为1的匹配节点
            if(i == start || node->depth == 1)
            {
                verify_query_l1_depthlp(tran,i,node,simCache,start);
            }
            //其它位置
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    verify_query_l1_depthlp(tran,i,node,simCache,start);
                }
            }

            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }
    }
}

//DEPTH过滤的验证函数：仅进行深度过滤 + 标准Jaccard验证
//不进行长度过滤和位置过滤
void Trie::verify_query_l1_depthlp(Transaction *tran,int tranDepth,TrieNode * node,SimiCache *simCache, int start)
{
    vector<int> *nil = node->index->arr;

    //遍历节点索引中的所有候选项，不进行长度过滤
    for(int nilCurPos = 0; nilCurPos < nil->size(); nilCurPos++)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];

        int candStart = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);
        int candPos = abs(candStart - node->depth + 1);

        //标准Jaccard验证：使用verify_ASC_DESC函数，与NOP过滤完全相同
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }
    }
}

//LENGTH过滤：仅长度过滤，无深度过滤
//基于process_query_l1_nolp，去除深度过滤逻辑
void Trie::process_query_l1_lenlp(Transaction *tran, SimiCache *simCache)
{
    //安全检查
    if(!tran) {
        cout << "error：process_query_l1_lenlp - the pointer is null." << endl;
        return;
    }

    if(!simCache) {
        cout << "error：process_query_l1_lenlp - simCache is null pointer" << endl;
        return;
    }

    if(tran->length <= 0) {
        cout << "error：process_query_l1_lenlp - set length is 0 or <0，set ID: " << tran->id << endl;
        return;
    }

    int start, end;
    int k=0;
    map<TrieNode *,QueryNode> nodeMap;

    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }

        if(i < 0 || i >= tran->length) {
            cout << "error：index " << i << " more than set length " << tran->length << endl;
            break;
        }

        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {
            TrieNode * node = *it;

            //LENGTH过滤：无深度过滤，直接进行长度过滤验证

            //深度为1的匹配节点
            if(i == start || node->depth == 1)
            {
                verify_query_l1_lenlp(tran,i,node,simCache);
            }
            //其它位置
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    verify_query_l1_lenlp(tran,i,node,simCache);
                }
            }

            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }
    }
}

//LENGTH过滤的验证函数：使用标准NOP长度过滤 + Jaccard验证
//无深度过滤，无位置过滤，仅使用固定长度范围[minSize, maxSize]
void Trie::verify_query_l1_lenlp(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;
    //检测起始和终止位置
    int startIDLBound, nilStartPos=0, nilCurPos=0;

    startIDLBound = data->lenIdx[data->getLenNoLessThan(simCache->minSize)]->start;
    nilCurPos=nilStartPos=node->lowerLen>=simCache->minSize?0:binarygreaterpos(startIDLBound,&(*nil)[0],nil->size(),1);

    //遍历nil列表中符合长度范围的候选集，逐一验证与查询集的相似度
    while(nilCurPos<=nil->size()-1 && data->vec_trans[(*nil)[nilCurPos]]->length <= simCache->maxSize)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];

        int start = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);

        int candPos = abs(start - node->depth + 1);

        //标准Jaccard验证：与NOP过滤完全相同
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }

        nilCurPos++;
    }
    candidateSize += nilCurPos - nilStartPos+1;
}

//NO过滤的遍历函数：不过滤，直接验证
//无深度过滤，无长度过滤，直接遍历所有节点和所有候选集
void Trie::process_query_l1_noFilter(Transaction *tran, SimiCache *simCache)
{
    if(!simCache) {
        cout << "error：process_query_l1_noFilter - simCache is null pointer" << endl;
        return;
    }

    if(tran->length <= 0) {
        cout << "error：process_query_l1_noFilter - set length is 0 or <0，set ID: " << tran->id << endl;
        return;
    }

    int start, end;
    int k=0;
    map<TrieNode *,QueryNode> nodeMap;

    if(triePreOrder == PREFASC)
    {
        start = 0;
        end = simCache->maxPrefixLen-1;
    }
    else
    {
        start = simCache->maxPrefixLen-1;
        end = 0;
    }

    for(int i=start;;)
    {
        if(triePreOrder == PREFASC)
        {
            if( i > end)
                break;
        }
        else
        {
            if(i < end)
                break;
        }

        if(i < 0 || i >= tran->length) {
            cout << "error：index " << i << " more than set length " << tran->length << endl;
            break;
        }

        vector<TrieNode *> nodes = sLNodes[tran->t[i]];
        vector<TrieNode *>::iterator it;
        for(it=nodes.begin();it!=nodes.end();it++)
        {
            TrieNode * node = *it;

            //NO过滤：无任何过滤，直接验证

            //深度为1的匹配节点
            if(i == start || node->depth == 1)
            {
                verify_query_l1_noFilter(tran,i,node,simCache);
            }
            //其它位置
            else
            {
                int stride =0;
                TrieNode * ancestornode = findNearestAncestor_l1_ADESC(node,tran,i,simCache,stride);
                if(!ancestornode)
                {
                    verify_query_l1_noFilter(tran,i,node,simCache);
                }
            }

            nodesaccessed++;
        }

        if(triePreOrder == PREFASC)
        {
            i++;
        }
        else
        {
            i--;
        }
    }
}

//NO过滤的验证函数：不过滤，直接Jaccard验证
//无深度过滤，无长度过滤，直接遍历整个nil列表
void Trie::verify_query_l1_noFilter(Transaction *tran,int tranDepth,TrieNode * node, SimiCache *simCache)
{
    vector<int> *nil = node->index->arr;

    //直接遍历整个nil列表，无任何长度过滤
    int nilStartPos = 0;
    int nilCurPos = 0;

    while(nilCurPos <= nil->size()-1)
    {
        Transaction *candTran = data->vec_trans[(*nil)[nilCurPos]];

        int start = (triePreOrder==PREFASC? 0: Similarity::getMaxPrefix(candTran->length,simType,cThres) -1);

        int candPos = abs(start - node->depth + 1);

        //标准Jaccard验证：与NOP过滤完全相同
        totalCandidatesVerified++;  // 统计传入验证的候选集数目
        if(verify_ASC_DESC(tran,candTran,tranDepth-1,candPos-1,tranDepth+1,candPos+1,1,simCache->minOverlap[candTran->length]))
        {
            resultSize++;
            totalCandidatesPassed++;  // 统计通过验证的候选集数目
        }

        nilCurPos++;
    }
    candidateSize += nilCurPos - nilStartPos+1;
}
