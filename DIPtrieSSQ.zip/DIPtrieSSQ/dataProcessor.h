#ifndef DATA_PROCESSOR_H
#define DATA_PROCESSOR_H
#include "data.h"
#include "util.h"
class DataProcessor
{
public:
    DataProcessor(Data *d,LenOrder lo,ElementOrder eo,LenLexOrder llo){data=d;lOrder = lo; eOrder=eo;llOrder = llo;}
    void process();
private:

    LenOrder lOrder;
    ElementOrder eOrder;
    LenLexOrder llOrder;
    Data *data;

};

#endif
