/*#include <iostream>
#include "util.h"
#include "data.h"
#include "dataProcessor.h"
#include <string.h>
using namespace std;

int main()
{
    char dstfile[200];
    int destDataType= FLAT;
    //FLAT  BINARY
    int datatype =FLAT;
    //WORDFRE_ASC  WORDFRE_DESC
    ElementOrder eOrder =  WORDFRE_ASC;
    LenOrder lOrder = LEN_DESC;

    //if two sets have an equal length, we sort it in ascending lexically
    LenLexOrder llOrder = LEN_LEX_ASC;

    strcpy(dstfile,datafile);

    if(lOrder==LEN_ASC)
        strcat(dstfile,"_lenA");
    else if(lOrder==LEN_DESC)
        strcat(dstfile,"_lenD");

    if(eOrder==WORDFRE_ASC)
        strcat(dstfile,"_freA");
    else if(eOrder==WORDFRE_DESC)
        strcat(dstfile,"_freD");
    else if(eOrder==LEX_ASC)
        strcat(dstfile,"_lexA");
    else if(eOrder==LEX_DESC)
        strcat(dstfile,"_lexD");

//    if(llOrder==LEN_ASC)
//        strcat(dstfile,"_llA");
//    else if(llOrder==LEN_DESC)
//        strcat(dstfile,"_llD");

    Data *data =  new Data(datafile,datatype);
    data->readData();

    DataProcessor *processor = new DataProcessor(data,lOrder,eOrder,llOrder);
    processor->process();


    data->outPut(dstfile,destDataType);

    return 0;
}
*/
